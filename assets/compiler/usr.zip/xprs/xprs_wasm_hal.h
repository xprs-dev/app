/*
 * XPRS WASM HAL — Hardware Abstraction Layer
 *
 * Modules #include this header and call hal_* functions normally.
 * Each host platform (ESP32/Wasm3, Flutter/Wasmer, CLI/Wasmtime) provides
 * its own implementation of these imports.
 *
 * Buffer exchanges use (ptr, len) pairs into WASM linear memory.
 * Functions that need hardware return sentinel values when the capability
 * is absent — modules should check *_available_hw() before using.
 *
 * Copyright (c) Max Brito and XPRS contributors — BSD-3-Clause
 */

#ifndef XPRS_WASM_HAL_H
#define XPRS_WASM_HAL_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ── System ─────────────────────────────────────────────────────────── */

/* Monotonic milliseconds since host start */
__attribute__((import_module("hal"), import_name("time_ms")))
uint64_t hal_time_ms(void);

/* Unix epoch seconds (0 if no RTC) */
__attribute__((import_module("hal"), import_name("time_epoch")))
uint64_t hal_time_epoch(void);

/* Minutes EAST of UTC for this device right now (DST included: +120 in CEST).
 * Epochs travel as UTC — two phones in different zones must agree on the wire
 * — so this is what turns one into a wall clock the reader recognises. */
__attribute__((import_module("hal"), import_name("time_utc_offset")))
int32_t hal_time_utc_offset(void);

/* Log a message. level: 0=debug, 1=info, 2=warn, 3=error */
__attribute__((import_module("hal"), import_name("log")))
void hal_log(int32_t level, const char *msg, uint32_t msg_len);

/* Yield to host scheduler (cooperative multitasking on ESP32) */
__attribute__((import_module("hal"), import_name("yield")))
void hal_yield(void);

/* Platform identifier written into buf. Returns bytes written. */
/* Platforms: "esp32", "android", "linux-desktop", "linux-cli" */
__attribute__((import_module("hal"), import_name("platform")))
uint32_t hal_platform(char *buf, uint32_t buf_len);

/* This device's identity (the active profile's callsign) written into buf.
 * Returns bytes written (0 if none). Use it as the default callsign instead
 * of hardcoding one, so each device transmits as itself. */
__attribute__((import_module("hal"), import_name("identity")))
uint32_t hal_identity(char *buf, uint32_t buf_len);

/* This device's public key — the active profile's Nostr public key in bech32
 * form ("npub1..."), written into buf. Returns bytes written (0 if none).
 * Lets a wapp publish its identity key so peers can map callsign -> pubkey
 * (e.g. to later send it encrypted messages). */
__attribute__((import_module("hal"), import_name("identity_pubkey")))
uint32_t hal_identity_pubkey(char *buf, uint32_t buf_len);

/* Sign [msg_len] bytes with THIS device's private key and write the signature,
 * as a compact ASCII string, into out_buf. The private key never leaves the
 * host. Returns bytes written (0 if no key / no room). The scheme is XPRS
 * short-Schnorr over secp256k1: a 48-byte signature, base85-encoded (60 chars).
 * Verify with hal_verify against the signer's hal_identity_pubkey. */
__attribute__((import_module("hal"), import_name("identity_sign")))
uint32_t hal_identity_sign(const char *msg, uint32_t msg_len,
                           char *out_buf, uint32_t out_len);

/* Verify a signature produced by hal_identity_sign. [pubkey] is the signer's
 * public key string exactly as hal_identity_pubkey returns it (base64url of the
 * 32-byte key); [msg] is the signed bytes; [sig] is the base85 signature string.
 * Returns 1 if valid, 0 otherwise. */
__attribute__((import_module("hal"), import_name("verify")))
uint32_t hal_verify(const char *pubkey, uint32_t pubkey_len,
                    const char *msg, uint32_t msg_len,
                    const char *sig, uint32_t sig_len);

/* Encode a public key (base64url of the 32 raw bytes, as hal_identity_pubkey
 * emits) to its npub bech32 string ("npub1..."), written into out_buf. Returns
 * bytes written (0 on error). Lets a wapp display the familiar npub form. */
__attribute__((import_module("hal"), import_name("npub")))
uint32_t hal_npub(const char *pubkey, uint32_t pubkey_len,
                  char *out_buf, uint32_t out_len);

/* Encrypt [msg] for [pubkey] (base64url of the 32 raw bytes) with THIS device's
 * private key (ECDH + AES-256-CBC). Writes base64url(iv||ciphertext) into
 * out_buf. Returns bytes written (0 on error). Decrypt with hal_decrypt on the
 * peer using the sender's pubkey. The private key never leaves the host. */
__attribute__((import_module("hal"), import_name("encrypt")))
uint32_t hal_encrypt(const char *pubkey, uint32_t pubkey_len,
                     const char *msg, uint32_t msg_len,
                     char *out_buf, uint32_t out_len);

/* Decrypt a base64url blob (from hal_encrypt) sent by [pubkey] (base64url),
 * using this device's private key. Writes the plaintext into out_buf. Returns
 * bytes written (0 on failure / not for us). */
__attribute__((import_module("hal"), import_name("decrypt")))
uint32_t hal_decrypt(const char *pubkey, uint32_t pubkey_len,
                     const char *blob, uint32_t blob_len,
                     char *out_buf, uint32_t out_len);

/* ── Media archive + decentralized sharing (XPRS section 16 / Files wapp) ─────
 * The host keeps a device-wide content-addressed archive (sha256 → bytes,
 * media.zx) plus a Blossom-compatible HTTP provider endpoint and a
 * BitTorrent seeder. Hashes are accepted as a full "file:<sha256>.<ext>"
 * token, a bare 43-char base64url digest, or 64-char hex. All JSON I/O. */

/* Page of archive metadata (newest first) as a JSON array. Returns bytes
 * written (0 = none/unavailable). */
__attribute__((import_module("hal"), import_name("media_list")))
uint32_t hal_media_list(int32_t offset, int32_t limit,
                        char *out_buf, uint32_t out_len);

/* One entry's metadata as JSON. 0 = unknown hash. */
__attribute__((import_module("hal"), import_name("media_meta")))
uint32_t hal_media_meta(const char *hash, uint32_t hash_len,
                        char *out_buf, uint32_t out_len);

/* Import a host file (absolute path, e.g. from a file.pick result) into the
 * archive. Writes the wire token "file:<sha256>.<ext>". 0 = failure. */
__attribute__((import_module("hal"), import_name("media_put_file")))
uint32_t hal_media_put_file(const char *path, uint32_t path_len,
                            char *out_buf, uint32_t out_len);

/* Update {"name","description","tags":[..]} (absent keys unchanged). */
__attribute__((import_module("hal"), import_name("media_set_meta")))
uint32_t hal_media_set_meta(const char *hash, uint32_t hash_len,
                            const char *json, uint32_t json_len);

__attribute__((import_module("hal"), import_name("media_delete")))
uint32_t hal_media_delete(const char *hash, uint32_t hash_len);

/* {"count":n,"bytes":n,"screenshots":n} */
__attribute__((import_module("hal"), import_name("media_stats")))
uint32_t hal_media_stats(char *out_buf, uint32_t out_len);

/* Search the archive. An exact sha256 (token / 43-char base64url / 64-hex)
 * returns that single entry; any other text is a full-text query over
 * name/description/tags/folder/parent. → JSON array of metadata objects. */
__attribute__((import_module("hal"), import_name("media_search")))
uint32_t hal_media_search(const char *query, uint32_t query_len,
                          char *out_buf, uint32_t out_len);

/* Virtual-folder tree: JSON array of {"parent","folder","count"}. */
__attribute__((import_module("hal"), import_name("media_folders")))
uint32_t hal_media_folders(char *out_buf, uint32_t out_len);

/* Files inside one virtual folder. Input JSON {"parent":..,"folder":..}
 * (empty strings = uncategorized). → JSON array of metadata objects. */
__attribute__((import_module("hal"), import_name("media_list_folder")))
uint32_t hal_media_list_folder(const char *json, uint32_t json_len,
                               char *out_buf, uint32_t out_len);

/* ── Mutable folders (IPNS-like; folder = secp256k1 identity on the relay) ──
 * Create a folder: input {"name":..,"desc":..} → folderId hex written to out. */
__attribute__((import_module("hal"), import_name("folder_create")))
uint32_t hal_folder_create(const char *json, uint32_t json_len,
                           char *out_buf, uint32_t out_len);

/* Owned folders → JSON array of {"folderId","npub","name"}. */
__attribute__((import_module("hal"), import_name("folder_list")))
uint32_t hal_folder_list(char *out_buf, uint32_t out_len);

/* Apply an edit to a folder. op JSON is one of:
 *   {"op":"addFile","x":<sha256hex>,"name":..,"desc":..,"mime":..,"size":..}
 *   {"op":"rmFile","x":<sha256hex>} / {"op":"setMeta","name":..,"desc":..}
 *   {"op":"link","f":<folderId>,"name":..} / {"op":"unlink","f":<folderId>}
 *   {"op":"grant","p":<npub-hex>,"role":..} / {"op":"revoke","p":<npub-hex>}
 * Asynchronous: returns 1 when the edit was accepted for publishing. */
__attribute__((import_module("hal"), import_name("folder_edit")))
uint32_t hal_folder_edit(const char *folder_id, uint32_t id_len,
                         const char *json, uint32_t json_len);

/* Browse a folder by id → its cached FolderState JSON {folderId,name,desc,
 * files[],links[],admins[]}. Triggers a background refresh; poll again for
 * fresh data (empty/partial on the first call). */
__attribute__((import_module("hal"), import_name("folder_browse")))
uint32_t hal_folder_browse(const char *folder_id, uint32_t id_len,
                           char *out_buf, uint32_t out_len);

/* Browse ONE directory level: pass "folder_id\tsubpath" as folder_id (subpath
 * "" = root, else ends with '/'). Returns JSON {name, npub, path, dirs:[{name}],
 * files:[{x,name,base,size,ts,dl}], links}. Keeps payload + work flat for huge
 * folders (only the immediate children of that path). */

/* Folder info + serve statistics for the info panel → JSON
 * {npub, name, owned, fileCount, totalBytes, serves, last24h, last7d, last30d,
 *  activeDays, top:[{name,serves}]}. */
__attribute__((import_module("hal"), import_name("folder_stats")))
uint32_t hal_folder_stats(const char *folder_id, uint32_t id_len,
                          char *out_buf, uint32_t out_len);

/* Stop sharing an owned disk folder (its on-disk files are left untouched).
 * Returns 1 when accepted. */
__attribute__((import_module("hal"), import_name("folder_remove")))
uint32_t hal_folder_remove(const char *folder_id, uint32_t id_len);

/* Open an owned disk folder's directory in the OS file manager so the user can
 * edit its files directly. Returns 1 if it's a known disk folder. */
__attribute__((import_module("hal"), import_name("folder_opendir")))
uint32_t hal_folder_opendir(const char *folder_id, uint32_t id_len);

/* ── Disk-backed owner folders + consumer downloads ──
 * Register an on-disk directory as an owned folder (files served from disk, not
 * copied to the archive). Asynchronous: returns 1 when started; poll
 * hal_folder_owned for the resulting folderId. */
__attribute__((import_module("hal"), import_name("folder_add_disk")))
uint32_t hal_folder_add_disk(const char *path, uint32_t path_len);

/* Re-scan owned disk folders and sync changes (one if folder_id given, else
 * all when id_len==0). Asynchronous; returns 1 when started. */
__attribute__((import_module("hal"), import_name("folder_rescan")))
uint32_t hal_folder_rescan(const char *folder_id, uint32_t id_len);

/* Download from a folder. json is {"sha":..,"name":..} for one file, or
 * {"all":true} for the whole folder. Asynchronous; returns 1 when started. */
__attribute__((import_module("hal"), import_name("folder_download")))
uint32_t hal_folder_download(const char *folder_id, uint32_t id_len,
                            const char *json, uint32_t json_len);

/* Turn auto-sync on/off for a folder (on != 0). */
__attribute__((import_module("hal"), import_name("folder_autosync")))
uint32_t hal_folder_autosync(const char *folder_id, uint32_t id_len, int32_t on);

/* Owned disk folders → JSON [{"folderId","dir","files"}]. */
__attribute__((import_module("hal"), import_name("folder_owned")))
uint32_t hal_folder_owned(char *out_buf, uint32_t out_len);

/* Folder subscriptions → JSON [{"folderId","autoSync","downloaded"}]. */
__attribute__((import_module("hal"), import_name("folder_subs")))
uint32_t hal_folder_subs(char *out_buf, uint32_t out_len);

/* 1 when a UI page is attached to this engine, 0 when it is headless (running
 * as a background service). A wapp that renders lists on a tick should check
 * this first: a background engine's ui.* messages are read by NOBODY, and
 * building them still costs main-isolate time. Keep the work that has a reason
 * to run with the screen off (receiving, notifying, seeding); skip the rest. */
__attribute__((import_module("hal"), import_name("ui_attached")))
int32_t hal_ui_attached(void);

/* The folder's shareable pointer: "ntorrent1..." (docs/torrents.md §11) — the
 * folder key plus up to 3 provider hints and the publisher. Accepts hex, npub
 * or ntorrent as input. */
__attribute__((import_module("hal"), import_name("folder_link")))
uint32_t hal_folder_link(const char *folder_id, uint32_t id_len,
                         char *out_buf, uint32_t out_len);

/* Who has this folder (the swarm) → JSON array, best holder first:
 *   [{"dest","pubkey","provenance":"direct"|"dht","lastHeardMs","hops",
 *     "capacity","role","power","poweredPct","uplink","bwClass","region",
 *     "radios":[..]}]
 * Ranked host-side: an awake machine on mains and a fat uplink first, a battery
 * phone on cellular last. Answers from the last snapshot immediately and
 * refreshes in the background (60s TTL) — poll again for fresher data. */
__attribute__((import_module("hal"), import_name("folder_swarm")))
uint32_t hal_folder_swarm(const char *folder_id, uint32_t id_len,
                          char *out_buf, uint32_t out_len);

/* Pin/unpin a folder (on != 0): keep a full copy on this device, follow its
 * op-log, and advertise ourselves to the Archivers as a holder. Returns 1 when
 * accepted. */
__attribute__((import_module("hal"), import_name("folder_pin")))
uint32_t hal_folder_pin(const char *folder_id, uint32_t id_len, int32_t on);

/* Device-local popularity of a folder over recent months → JSON
 * {folderId, months:[{ym, seeders, leechers}]} where ym = year*100 + month.
 * Kept on THIS device only, never in the folder. */
__attribute__((import_module("hal"), import_name("folder_popularity")))
uint32_t hal_folder_popularity(const char *folder_id, uint32_t id_len,
                               char *out_buf, uint32_t out_len);

/* Enable/disable pulling the publisher's updates for a folder (on == 0 freezes
 * it at the version you hold — a static copy, no re-downloads; on != 0 resumes
 * following changes). Returns 1 when accepted. */
__attribute__((import_module("hal"), import_name("folder_set_updates")))
uint32_t hal_folder_set_updates(const char *folder_id, uint32_t id_len, int32_t on);

/* Whether a folder currently follows the publisher's updates: 1 = updates on
 * (the default), 0 = frozen. */
__attribute__((import_module("hal"), import_name("folder_updates")))
int32_t hal_folder_updates(const char *folder_id, uint32_t id_len);

/* ── The listing: data/meta.json (aurora/docs/torrents.md) ──────────────────
 * A shared folder describes itself with ordinary files inside it:
 *   data/meta.json     title, desc, cat, tags, adult, + the media names
 *   data/cover.jpg     poster        data/banner.jpg   wide header
 *   data/trailer.webm  clip          data/media1..10.{png,jpg,webm}  gallery
 * It TRAVELS with the content (data/ is published like any other file) and a
 * human can write it with a text editor. The signed op-log mirrors the fields,
 * so a stranger reads the title and filters by category WITHOUT downloading.
 */

/* The listing of a folder we own → the meta.json shape:
 * {"title","desc","cat","tags":[..],"adult",cover,banner,trailer,gallery:[..]}
 * Empty object when the folder has no listing (the normal case). */
__attribute__((import_module("hal"), import_name("folder_meta_get")))
uint32_t hal_folder_meta_get(const char *folder_id, uint32_t id_len,
                             char *out_buf, uint32_t out_len);

/* Write the listing (same JSON). Rewrites data/meta.json and rescans, which
 * publishes it and mirrors title/desc/cat/tags/adult into the signed op-log.
 * Every limit (title 50, desc 200, 10 tags, the fixed category set) is enforced
 * host-side, so a wapp cannot publish a listing that other clients will refuse.
 * Returns 1 when accepted. */
__attribute__((import_module("hal"), import_name("folder_meta_set")))
uint32_t hal_folder_meta_set(const char *folder_id, uint32_t id_len,
                             const char *json, uint32_t json_len);

/* Copy a picked file into data/ under its FIXED name (cover.jpg, trailer.webm,
 * media3.png …) — the name is what tells a client what the file is, and the
 * extension whether a gallery item is a still or a clip.
 * arg = "slot\tpath", slot = cover | banner | trailer | gallery.
 * Each media file is capped at 30MB: data/ is what a browsing client pulls
 * BEFORE deciding to download the torrent, so it has to stay cheap.
 * Asynchronous; 1 = started (a refusal is reported in the host log). */
__attribute__((import_module("hal"), import_name("folder_set_media")))
uint32_t hal_folder_set_media(const char *folder_id, uint32_t id_len,
                              const char *arg, uint32_t arg_len);

/* The listing's artwork as media TOKENS the host can render:
 *   {"cover":{"token":"file:<sha>.jpg","have":true,"size":n}, "banner":{..},
 *    "trailer":{..}, "gallery":[{..},..]}
 * Bytes we do not hold are fetched in the background — data/ is small, so the
 * cover of a torrent you have NOT downloaded still fills in. Feed the whole JSON
 * to a `$type:"gallery"` field with ui.field.set and the host draws it. */
__attribute__((import_module("hal"), import_name("folder_media")))
uint32_t hal_folder_media(const char *folder_id, uint32_t id_len,
                          char *out_buf, uint32_t out_len);

/* Search the listings this node knows (owned + subscribed). query = JSON
 *   {"q":"free text","cat":"film","sort":"seeders|updated|size"}
 * → {"cats":[{"cat":"film","count":12},..],
 *    "results":[{"folderId":..,"title":..,"cat":..,"adult":bool,
 *                "seeders":n,"size":bytes,"updated":ts},..]}
 * `q` matches title/name/description/tags; `cats` lists only non-empty buckets so
 * a browser can hide empty categories. Generic — no torrent-specific logic. */
__attribute__((import_module("hal"), import_name("folder_search")))
uint32_t hal_folder_search(const char *query, uint32_t query_len,
                           char *out_buf, uint32_t out_len);

/* Search folder listings across the MESH as well as the local index. Same
 * query/result contract as folder_search, plus:
 *   "busy": true   — the mesh fan-out is still in flight; poll again in a
 *                    second or two and the results will have filled in.
 *   per-row "where": "local" | "mesh" | "both" — where the listing was found.
 * Mesh rows carry seeders/size 0 (a DHT walk per row would turn one search
 * into fifty); they resolve the moment the torrent is opened. */
__attribute__((import_module("hal"), import_name("folder_search_global")))
uint32_t hal_folder_search_global(const char *query, uint32_t query_len,
                                  char *out_buf, uint32_t out_len);

/* Download library — real files on disk, organized in subfolders.
 *   folder_download_root: current download folder path (empty if unset).
 *   folder_set_download_root(path): choose it; adopts torrents already under it.
 *   folder_library(relPath) → {"root","path","dirs":[{"name"}],
 *       "torrents":[{"folderId","name","owned"}]}  — one level of the tree.
 *   folder_mkdir(relPath): create an organizing subfolder under the root.
 *   folder_move("folderId\trelPath"): move a torrent into a subfolder. */
__attribute__((import_module("hal"), import_name("folder_download_root")))
uint32_t hal_folder_download_root(char *out_buf, uint32_t out_len);
__attribute__((import_module("hal"), import_name("folder_set_download_root")))
uint32_t hal_folder_set_download_root(const char *path, uint32_t path_len);
__attribute__((import_module("hal"), import_name("folder_library")))
uint32_t hal_folder_library(const char *rel, uint32_t rel_len,
                            char *out_buf, uint32_t out_len);
__attribute__((import_module("hal"), import_name("folder_mkdir")))
uint32_t hal_folder_mkdir(const char *rel, uint32_t rel_len);
__attribute__((import_module("hal"), import_name("folder_move")))
uint32_t hal_folder_move(const char *arg, uint32_t arg_len);

/* Open ONE file of a folder with whatever the system uses to view that type —
 * the gallery for a photo, a reader for a PDF, the installer for an APK.
 * arg = "<sha256hex>\t<name>" (the name carries the extension the OS routes on).
 * Asynchronous: returns 1 when started. A file we never downloaded, or a type no
 * app here can open, fails honestly and is reported in the host log. Files served
 * from a disk folder are opened in place; downloaded ones are exported out of the
 * content-addressed archive on a WORKER isolate first. */
__attribute__((import_module("hal"), import_name("folder_open_file")))
uint32_t hal_folder_open_file(const char *folder_id, uint32_t id_len,
                              const char *arg, uint32_t arg_len);

/* List a real directory for an in-app folder browser → JSON array of
 * {"name","path","dir"} (directories first). Empty/0 if not accessible. */
__attribute__((import_module("hal"), import_name("fs_listdir")))
uint32_t hal_fs_listdir(const char *path, uint32_t path_len,
                        char *out_buf, uint32_t out_len);

/* Request broad file access (Android "all files"). Returns 1 (the system access
 * screen opens on Android); poll hal_fs_listdir afterwards. */
__attribute__((import_module("hal"), import_name("storage_request")))
uint32_t hal_storage_request(int32_t unused);

/* A good starting directory for the in-app browser (Android primary storage,
 * else the desktop home dir) → its path. */
__attribute__((import_module("hal"), import_name("fs_home")))
uint32_t hal_fs_home(char *out_buf, uint32_t out_len);

/* Ask the core for the bytes behind a token. Asynchronous: 1 = the request was
 * taken (or the file is already held); watch `core.media` for the answer.
 *
 * THE CORE CHOOSES THE LANE. It looks in the store first (a file obtained once
 * is never fetched again), then picks by size and by what actually reaches a
 * holder: the packet lane for small files, which crosses a public hub; the
 * bulk lane where a BLE session or a LAN peer exists; Reticulum, Blossom or
 * the swarm over the internet. A wapp asking for a file states a want, not a
 * route (docs/architecture.md section 3). */
__attribute__((import_module("hal"), import_name("media_fetch")))
uint32_t hal_media_fetch(const char *token, uint32_t token_len);

/* What the core is doing about one reference → JSON, or 0 if the token does
 * not parse:
 *
 *   {"state":"absent|seeking|fetching|ready|failed",
 *    "received":<bytes so far>, "total":<bytes expected>,
 *    "size":<announced size>, "name":"...", "ext":"jpg",
 *    "original":"<token>"}
 *
 * `original` is the full-resolution file a carried preview stands for, and is
 * empty when the message carries the file itself (XPRS.md 7.7.7). Read it on a
 * `core.media` event, not on a timer. */
__attribute__((import_module("hal"), import_name("media_state")))
uint32_t hal_media_state(const char *token, uint32_t token_len,
                         char *out_buf, uint32_t out_len);

/* Hand a held file to whatever this device uses to view that type. 1 = the
 * export started; 0 = the token does not parse or the bytes are not held yet.
 * The bytes go from the store to a temporary file on a worker isolate; they
 * never pass through the wapp. */
__attribute__((import_module("hal"), import_name("media_open")))
uint32_t hal_media_open(const char *token, uint32_t token_len);

/* Fetch from a magnet: link (the cross-internet path). [expected] is an
 * optional file:token to verify the downloaded content against. */
__attribute__((import_module("hal"), import_name("media_fetch_magnet")))
uint32_t hal_media_fetch_magnet(const char *magnet, uint32_t magnet_len,
                                const char *expected, uint32_t expected_len);

/* Record a source for a hash. kind = "blossom" (base URL), "infohash"
 * (40-hex) or "callsign". */
__attribute__((import_module("hal"), import_name("media_add_source")))
uint32_t hal_media_add_source(const char *token, uint32_t token_len,
                              const char *kind, uint32_t kind_len,
                              const char *value, uint32_t value_len);

/* A shareable magnet: link for an archived token (the reference handed to a
 * peer on another network to fetch over BitTorrent). Built in the background:
 * returns 0 until ready, then the magnet on a later call. */
__attribute__((import_module("hal"), import_name("media_magnet")))
uint32_t hal_media_magnet(const char *token, uint32_t token_len,
                          char *out_buf, uint32_t out_len);

/* The deterministic torrent infohash (40-hex) for an archived token. The
 * sender appends "ih:<hex>" to a share message so the receiver can join the
 * swarm. Built in the background: 0 until ready, then the hex on a later
 * call. */
__attribute__((import_module("hal"), import_name("media_infohash")))
uint32_t hal_media_infohash(const char *token, uint32_t token_len,
                            char *out_buf, uint32_t out_len);

/* Apply sharing controls: {"server":bool,"port":n,"uploads":bool,
 * "seed":bool}. server = Blossom HTTP endpoint; seed = BitTorrent. */
__attribute__((import_module("hal"), import_name("share_ctl")))
uint32_t hal_share_ctl(const char *json, uint32_t json_len);

/* {"server":{"running":b,"port":n,"uploads":b,"requests":n,"bytes":n},
 *  "torrents":[{"infohash","token","seeding","progress","peers"},..]} */
__attribute__((import_module("hal"), import_name("share_status")))
uint32_t hal_share_status(char *out_buf, uint32_t out_len);

/* Routine LAN scan for Blossom servers: probes the local network and refreshes
 * the host's cached directory of reachable Aurora Blossom servers. Call it
 * periodically (NOT per message). Writes a JSON array of base URLs to out_buf;
 * returns the count of reachable servers. */
__attribute__((import_module("hal"), import_name("lan_scan")))
uint32_t hal_lan_scan(char *out_buf, uint32_t out_len);

/* Free heap bytes available to this module */
__attribute__((import_module("hal"), import_name("heap_free")))
uint32_t hal_heap_free(void);

/* ── Storage (key-value, scoped per module ID) ──────────────────────── */

/* Get value for key. Returns bytes written to val_buf, 0 if not found. */
__attribute__((import_module("hal"), import_name("kv_get")))
uint32_t hal_kv_get(const char *key, uint32_t key_len,
                    char *val_buf, uint32_t val_buf_len);

/* Set key=value. Returns 0 on success, -1 on error. */
__attribute__((import_module("hal"), import_name("kv_set")))
int32_t hal_kv_set(const char *key, uint32_t key_len,
                   const char *val, uint32_t val_len);

/* Delete key. Returns 0 on success, -1 if not found. */
__attribute__((import_module("hal"), import_name("kv_delete")))
int32_t hal_kv_delete(const char *key, uint32_t key_len);

/* List keys matching prefix. Writes null-separated key names into buf.
 * Returns number of keys found (0 if none). */
__attribute__((import_module("hal"), import_name("kv_list")))
uint32_t hal_kv_list(const char *prefix, uint32_t prefix_len,
                     char *buf, uint32_t buf_len);

/* Check if key exists. Returns 1 if exists, 0 if not. */
__attribute__((import_module("hal"), import_name("kv_exists")))
int32_t hal_kv_exists(const char *key, uint32_t key_len);

/* Get size of value for key. Returns size in bytes, 0 if not found. */
__attribute__((import_module("hal"), import_name("kv_size")))
uint32_t hal_kv_size(const char *key, uint32_t key_len);

/* ── Internationalisation ───────────────────────────────────────────── */

/* Look up a translation key against the wapp's lang/<locale>.json
 * (merged with the English fallback). Writes up to out_cap bytes of
 * the localised string into out (NOT null-terminated). Returns the
 * number of bytes written. When the key is missing from both the
 * primary and fallback maps, returns 0 and out is untouched — the
 * caller should fall back to its hard-coded literal. */
__attribute__((import_module("hal"), import_name("i18n_get")))
uint32_t hal_i18n_get(const char *key, uint32_t key_len,
                      char *out, uint32_t out_cap);

/* ── Storage (host filesystem, no sandbox) ──────────────────────────
 *
 * Absolute paths only. Same trust model as hal_process_exec — wapps
 * have full filesystem access at the privilege level of the xprs
 * process.
 *
 * Reads slurp the whole file at open and serve from a buffer; writes
 * accumulate in memory and flush at close. The host creates parent
 * directories automatically on write/append open as a convenience.
 */

/* Open file. mode: 0=read, 1=write, 2=append. Returns handle or -1.
 * Path must be absolute. */
__attribute__((import_module("hal"), import_name("file_open")))
int32_t hal_file_open(const char *path, uint32_t path_len, int32_t mode);

/* Read up to buf_len bytes. Returns bytes read, 0 on EOF, -1 on error. */
__attribute__((import_module("hal"), import_name("file_read")))
int32_t hal_file_read(int32_t handle, char *buf, uint32_t buf_len);

/* Write buf_len bytes. Returns bytes written or -1 on error. */
__attribute__((import_module("hal"), import_name("file_write")))
int32_t hal_file_write(int32_t handle, const char *buf, uint32_t buf_len);

/* Close file handle. */
__attribute__((import_module("hal"), import_name("file_close")))
void hal_file_close(int32_t handle);

/* ── Network (async polling) ────────────────────────────────────────── */

/* Start HTTP request. Returns request_id or -1 on error. */
/* method: 0=GET, 1=POST, 2=PUT, 3=DELETE */
__attribute__((import_module("hal"), import_name("http_request")))
int32_t hal_http_request(int32_t method,
                         const char *url, uint32_t url_len,
                         const char *body, uint32_t body_len);

/* Start an HTTP request with headers and a timeout. Returns request_id or
 * -1. method as above. headers: "Name: value" lines separated by '\n'
 * (e.g. "Authorization: Bearer ...\nContent-Type: application/json"), or
 * NULL/0. body: raw bytes, ignored for GET. timeout_ms: 1000..600000,
 * 0 = 30 s. Read and free exactly as for hal_http_request. No need to poll:
 * when the answer is in, the host delivers {"type":"http.done","id":<id>}
 * to module_handle_event, so a wapp waiting on one declares no clock. */
__attribute__((import_module("hal"), import_name("http_request2")))
int32_t hal_http_request2(int32_t method,
                          const char *url, uint32_t url_len,
                          const char *headers, uint32_t headers_len,
                          const char *body, uint32_t body_len,
                          int32_t timeout_ms);

/* Poll request status. Returns: 0=pending, 1=complete, -1=error */
__attribute__((import_module("hal"), import_name("http_poll")))
int32_t hal_http_poll(int32_t request_id);

/* Read response body. Returns bytes written to buf. */
__attribute__((import_module("hal"), import_name("http_read_response")))
int32_t hal_http_read_response(int32_t request_id, char *buf, uint32_t buf_len);

/* HTTP status code for completed request, or -1 if still pending. */
__attribute__((import_module("hal"), import_name("http_status")))
int32_t hal_http_status(int32_t request_id);

/* Free request resources. */
__attribute__((import_module("hal"), import_name("http_free")))
void hal_http_free(int32_t request_id);

/* ── Streaming HTTP (online radio) ──────────────────────────────────────
 * A long-lived GET whose body arrives over time. The host handles TLS,
 * redirects and ICY/SHOUTcast metadata (stripped out so reads return pure
 * audio; the latest StreamTitle is available via hal_http_stream_meta). */

/* Open a streaming GET. Returns a handle (>=0) immediately; data arrives in
 * the background. Returns -1 on bad arguments. */
__attribute__((import_module("hal"), import_name("http_stream_open")))
int32_t hal_http_stream_open(const char *url, uint32_t url_len);

/* Drain available audio bytes into buf. Returns bytes read (0 = none yet,
 * -1 = stream closed/ended and drained). */
__attribute__((import_module("hal"), import_name("http_stream_read")))
int32_t hal_http_stream_read(int32_t handle, char *buf, uint32_t buf_len);

/* Latest ICY StreamTitle into buf. Returns bytes written (0 if none). */
__attribute__((import_module("hal"), import_name("http_stream_meta")))
uint32_t hal_http_stream_meta(int32_t handle, char *buf, uint32_t buf_len);

/* Close the stream and release the handle. */
__attribute__((import_module("hal"), import_name("http_stream_close")))
void hal_http_stream_close(int32_t handle);

/* ── Raw TCP socket (async, host network) ───────────────────────────── */

/* Open a TCP connection. Returns a handle (>=0) immediately; the
 * connection resolves in the background — poll hal_socket_status until it
 * reports open. Returns -1 on bad arguments. */
__attribute__((import_module("hal"), import_name("socket_open")))
int32_t hal_socket_open(const char *host, uint32_t host_len, int32_t port);

/* Connection state: 0 = connecting, 1 = open, 2 = closed or error. */
__attribute__((import_module("hal"), import_name("socket_status")))
int32_t hal_socket_status(int32_t handle);

/* Queue bytes for transmission. Returns bytes accepted, or -1 on error. */
__attribute__((import_module("hal"), import_name("socket_send")))
int32_t hal_socket_send(int32_t handle, const char *buf, uint32_t len);

/* Drain received bytes into buf. Returns bytes read (0 if none yet). */
__attribute__((import_module("hal"), import_name("socket_recv")))
uint32_t hal_socket_recv(int32_t handle, char *buf, uint32_t buf_len);

/* Close the connection and release the handle. */
__attribute__((import_module("hal"), import_name("socket_close")))
void hal_socket_close(int32_t handle);

/* ── Synchronous (blocking) socket — for the test runner only ────────── *
 * The wasm test runner (module_run_tests) is one synchronous call and
 * can't await the async hal_socket_* above. These blocking variants let
 * a test connect/write/read within that single call: connect blocks,
 * `avail` returns kernel-buffered bytes without blocking, and `read`
 * pulls only what's already buffered. Bound your read loop with
 * hal_time_ms(). Do NOT use these in normal wapp code — they block. */
__attribute__((import_module("hal"), import_name("socket_open_sync")))
int32_t hal_socket_open_sync(const char *host, uint32_t host_len, int32_t port);

__attribute__((import_module("hal"), import_name("socket_avail_sync")))
int32_t hal_socket_avail_sync(int32_t handle);

__attribute__((import_module("hal"), import_name("socket_read_sync")))
int32_t hal_socket_read_sync(int32_t handle, char *buf, uint32_t buf_len);

__attribute__((import_module("hal"), import_name("socket_write_sync")))
int32_t hal_socket_write_sync(int32_t handle, const char *buf, uint32_t len);

__attribute__((import_module("hal"), import_name("socket_close_sync")))
void hal_socket_close_sync(int32_t handle);

/* ── Process (host subprocess) ──────────────────────────────────────
 *
 * Generic host-process primitive. The wapp asks the host to run a
 * binary — the host runs it as-is, with no sandbox and no allow
 * list. argv is a JSON array of strings, e.g.
 *
 *   ["/usr/bin/clang", "-O2", "-o", "/tmp/a.wasm", "/tmp/main.c"]
 *
 * cwd is an absolute working directory or empty for the host's CWD.
 * Always use absolute paths in argv. The host's PATH is not searched
 * for argv[0].
 *
 * Async polling, mirrors hal_http_*. After hal_process_exec returns
 * a handle, the wapp polls hal_process_poll each tick, drains
 * stdout/stderr with hal_process_read_*, and finally calls
 * hal_process_free to release the handle.
 *
 * Output buffers are unbounded host-side — the wapp can drain on
 * its own cadence without losing data, but should drain regularly
 * for long-running processes to keep host memory in check.
 */

/* Spawn a subprocess. Returns handle (>=0) or -1 on error. */
__attribute__((import_module("hal"), import_name("process_exec")))
int32_t hal_process_exec(const char *argv_json, uint32_t argv_json_len,
                         const char *cwd, uint32_t cwd_len);

/* Poll process state. Returns:
 *    0 = still running
 *    1 = exited (call hal_process_exit_code for the code)
 *   -1 = error or unknown handle
 */
__attribute__((import_module("hal"), import_name("process_poll")))
int32_t hal_process_poll(int32_t handle);

/* Exit code of a finished process. Returns -1 if the process is
 * still running or the handle is unknown. */
__attribute__((import_module("hal"), import_name("process_exit_code")))
int32_t hal_process_exit_code(int32_t handle);

/* Drain buffered stdout into buf. Returns bytes written, 0 if no
 * output is currently buffered. Output is raw bytes — caller owns
 * line splitting. */
__attribute__((import_module("hal"), import_name("process_read_stdout")))
uint32_t hal_process_read_stdout(int32_t handle,
                                 char *buf, uint32_t buf_len);

/* Drain buffered stderr into buf. Same semantics as
 * hal_process_read_stdout. */
__attribute__((import_module("hal"), import_name("process_read_stderr")))
uint32_t hal_process_read_stderr(int32_t handle,
                                 char *buf, uint32_t buf_len);

/* Release the handle. Kills the process if still running, drops any
 * unread buffered output. */
__attribute__((import_module("hal"), import_name("process_free")))
void hal_process_free(int32_t handle);

/* ── LoRa ───────────────────────────────────────────────────────────── */

/* Returns 1 if LoRa hardware is present, 0 otherwise. */
__attribute__((import_module("hal"), import_name("lora_available_hw")))
int32_t hal_lora_available_hw(void);

/* Send packet. Returns 0 on success, -1 on error. */
__attribute__((import_module("hal"), import_name("lora_send")))
int32_t hal_lora_send(const char *data, uint32_t data_len);

/* Returns number of bytes available to read, 0 if none. */
__attribute__((import_module("hal"), import_name("lora_available")))
uint32_t hal_lora_available(void);

/* Read received packet into buf. Returns bytes read. */
__attribute__((import_module("hal"), import_name("lora_recv")))
uint32_t hal_lora_recv(char *buf, uint32_t buf_len);

/* ── BLE ────────────────────────────────────────────────────────────── *
 *
 * THERE IS NO RAW BLE HAL. Not a scan, not a read, not an advertise.
 *
 * `ble_scan_read` handed a wapp every 0x41 advert this radio heard and every
 * reassembled GATT parcel, each carrying the advertiser's address and its
 * RSSI -- a transport address and a proximity signal -- for traffic addressed
 * to other people. The core delivered all of it and trusted the wapp to drop
 * what was not its business.
 *
 * `ble_advertise` was worse: it took arbitrary bytes and made the core SNIFF
 * them to choose the subtype byte for the wire. Through it a wapp ran a
 * digipeater of its own, re-airing other stations' frames on a staggered
 * schedule while appending no `via:` and paying no hop budget, and aired
 * frames under callsigns that were not this station's.
 *
 * A wapp says what it wants said with hal_xprs_message (or hal_xprs_send for
 * a packet it composed itself). What this radio hears arrives on the event
 * bus, demuxed, reassembled, unsealed and deduped, and only for the packet
 * types the wapp subscribed to. All that is left here is whether the adapter
 * is on.
 */

/* Whether the physical Bluetooth adapter is powered ON right now (the user can
 * toggle it at the OS level at any time). Returns 1 = on/usable, 0 = off. Use
 * this before claiming a BLE channel is available. */
__attribute__((import_module("hal"), import_name("ble_available")))
int32_t hal_ble_available(void);

/* ── Sensors ────────────────────────────────────────────────────────── */

/* Temperature in centidegrees C (2500 = 25.00°C). INT32_MIN if N/A. */
__attribute__((import_module("hal"), import_name("sensor_temperature")))
int32_t hal_sensor_temperature(void);

/* Relative humidity in centipercent (6500 = 65.00%). INT32_MIN if N/A. */
__attribute__((import_module("hal"), import_name("sensor_humidity")))
int32_t hal_sensor_humidity(void);

/* Battery millivolts (3700 = 3.7V). INT32_MIN if N/A. */
__attribute__((import_module("hal"), import_name("sensor_battery")))
int32_t hal_sensor_battery(void);

/* GPS latitude * 1e7 (e.g. 377749000 = 37.7749°N). INT32_MIN if N/A. */
__attribute__((import_module("hal"), import_name("sensor_gps_lat")))
int32_t hal_sensor_gps_lat(void);

/* GPS longitude * 1e7. INT32_MIN if N/A. */
__attribute__((import_module("hal"), import_name("sensor_gps_lon")))
int32_t hal_sensor_gps_lon(void);

/* ── Display ────────────────────────────────────────────────────────── */

/* Display width in pixels. 0 if no display. */
__attribute__((import_module("hal"), import_name("display_width")))
uint32_t hal_display_width(void);

/* Display height in pixels. 0 if no display. */
__attribute__((import_module("hal"), import_name("display_height")))
uint32_t hal_display_height(void);

/* Clear display buffer. */
__attribute__((import_module("hal"), import_name("display_clear")))
void hal_display_clear(void);

/* Draw text at (x,y). color: 0=black, 1=white. */
__attribute__((import_module("hal"), import_name("display_text")))
void hal_display_text(int32_t x, int32_t y, int32_t color,
                      const char *text, uint32_t text_len);

/* Set single pixel. */
__attribute__((import_module("hal"), import_name("display_pixel")))
void hal_display_pixel(int32_t x, int32_t y, int32_t color);

/* Draw filled rectangle. */
__attribute__((import_module("hal"), import_name("display_rect")))
void hal_display_rect(int32_t x, int32_t y, int32_t w, int32_t h, int32_t color);

/* Flush buffer to physical display. */
__attribute__((import_module("hal"), import_name("display_flush")))
void hal_display_flush(void);

/* ── Codec-free A/V sink ────────────────────────────────────────────────
 * The host contains NO codec. A media wapp decodes (e.g. mp4/H.264) IN
 * wasm and pushes the decoded frames/PCM here; the host only uploads the
 * raw pixels to a texture and (later) plays the raw samples. This keeps
 * the codec/player out of the host binary and makes playback platform
 * agnostic — the decoder travels inside the .wapp. */

/* Announce the video geometry before the first frame. pixfmt: 0 = RGBA8888. */
__attribute__((import_module("hal"), import_name("video_config")))
void hal_video_config(int32_t width, int32_t height, int32_t pixfmt);

/* Submit one decoded frame. `data` points into wasm linear memory; for
 * pixfmt 0 (RGBA8888) `len` must equal width*height*4. pts_ms is the
 * presentation timestamp in milliseconds from the start of the stream. */
__attribute__((import_module("hal"), import_name("video_frame")))
void hal_video_frame(const uint8_t *data, uint32_t len,
                     int32_t width, int32_t height,
                     int32_t pixfmt, int32_t pts_ms);

/* Submit one block of decoded PCM. sampfmt: 0 = s16 interleaved,
 * 1 = f32 interleaved. (Wired end-to-end; the MVP host drops audio.) */
__attribute__((import_module("hal"), import_name("audio_pcm")))
void hal_audio_pcm(const uint8_t *data, uint32_t len,
                   int32_t sample_rate, int32_t channels,
                   int32_t sampfmt, int32_t pts_ms);

/* Signal end of stream (playback reached the last frame). */
__attribute__((import_module("hal"), import_name("video_end")))
void hal_video_end(void);

/* ── GPIO (ESP32 only, no-op elsewhere) ─────────────────────────────── */

/* Set pin mode. mode: 0=input, 1=output, 2=input_pullup. */
__attribute__((import_module("hal"), import_name("gpio_mode")))
void hal_gpio_mode(int32_t pin, int32_t mode);

/* Read digital pin value (0 or 1). */
__attribute__((import_module("hal"), import_name("gpio_read")))
int32_t hal_gpio_read(int32_t pin);

/* Write digital pin value (0 or 1). */
__attribute__((import_module("hal"), import_name("gpio_write")))
void hal_gpio_write(int32_t pin, int32_t value);

/* ── Messages (host <-> module JSON) ────────────────────────────────── */

/* Send JSON message to host. */
__attribute__((import_module("hal"), import_name("msg_send")))
void hal_msg_send(const char *json, uint32_t json_len);

/* Returns number of bytes in next pending message, 0 if none. */
__attribute__((import_module("hal"), import_name("msg_available")))
uint32_t hal_msg_available(void);

/* Read next pending message into buf. Returns bytes read. */
__attribute__((import_module("hal"), import_name("msg_recv")))
uint32_t hal_msg_recv(char *buf, uint32_t buf_len);

/* ── Library calls (cross-module RPC) ───────────────────────────────── */

/* Call a function in a loaded library module.
 * Returns bytes written to result on success, or negative error code:
 *   -1 = library not found, -2 = function not found,
 *   -3 = buffer too small, -4 = internal error. */
__attribute__((import_module("hal"), import_name("lib_call")))
int32_t hal_lib_call(const char *lib_id, uint32_t lib_id_len,
                     const char *fn_name, uint32_t fn_name_len,
                     const char *args, uint32_t args_len,
                     char *result, uint32_t result_len);

/* ── Events (topic-based pub/sub) ───────────────────────────────────── *
 *
 * Two families arrive here, and a wapp subscribes to the ones it draws.
 *
 *   `xprs.<type>`   one topic per XPRS.md 4.2 packet type, plus
 *                   `xprs.status.tx` for what became of a message WE sent.
 *
 *   `core.<thing>`  the core's own state moved and whatever you read from it
 *                   is now stale. The event carries {"topic","rev"} and NOT
 *                   the data: read it with the call you already use, on
 *                   delivery instead of on a timer. Changes are coalesced, so
 *                   a burst of packets is one event, not one per packet.
 *
 *       core.monitor         the station table and the traffic ring
 *       core.rns.graph       announced Reticulum nodes and their hubs
 *       core.mesh.topology   the BLE neighbour table and its routes
 *       core.archive         the archive's counters and what is held
 *       core.media           a shared file moved: it arrived, its transfer
 *                            advanced, or it failed. Read hal_media_state for
 *                            the reference you are drawing.
 *
 * A wapp that subscribes to what it draws can declare
 * `module_tick_interval_ms() = 0` and have no clock at all. Before these
 * topics existed there was no way to be told any of it changed, so every
 * wapp that showed core state asked again every one to five seconds, whether
 * or not anything had happened.
 */

/* Subscribe to a topic. Returns 0 on success, -1 on error. */
__attribute__((import_module("hal"), import_name("event_subscribe")))
int32_t hal_event_subscribe(const char *topic, uint32_t topic_len);

/* Unsubscribe from a topic. Returns 0 on success, -1 if not subscribed. */
__attribute__((import_module("hal"), import_name("event_unsubscribe")))
int32_t hal_event_unsubscribe(const char *topic, uint32_t topic_len);

/* Publish data to a topic. Returns number of subscribers notified. */
__attribute__((import_module("hal"), import_name("event_publish")))
int32_t hal_event_publish(const char *topic, uint32_t topic_len,
                          const char *data, uint32_t data_len);

/* Returns size of next pending event (topic_len + data_len), 0 if none. */
__attribute__((import_module("hal"), import_name("event_available")))
uint32_t hal_event_available(void);

/* Read next pending event. Writes topic into topic_buf, data into data_buf.
 * Returns bytes written to data_buf, 0 if no event available. */
__attribute__((import_module("hal"), import_name("event_recv")))
uint32_t hal_event_recv(char *topic_buf, uint32_t topic_buf_len,
                        char *data_buf, uint32_t data_buf_len);

/* ── Database (hal.db: per-wapp SQL storage) ────────────────────────── *
 *
 * Generic database access for wapps: SQL in the SQLite dialect, run by the
 * host's zx database engine. `path` is RELATIVE to this wapp's private data
 * directory — a leading '/' and any ".." segment are rejected, so a wapp can
 * never reach another wapp's files or escape its sandbox. The database is
 * created if missing and stored as `<path>.zx` (a trailing .sqlite3, .sqlite
 * or .db is replaced); inside an encrypted profile it is encrypted.
 *
 * Binary values are NOT marshalled across the boundary: store binary as
 * base64 TEXT. Bind parameters are an optional JSON array matched to '?'
 * placeholders in order (JSON string/number/null → TEXT/INTEGER-or-REAL/
 * NULL); pass len 0 for none. Query rows come back as a JSON array of
 * objects (column name → value). Every statement outside BEGIN/COMMIT is
 * its own commit: group a burst of writes in one transaction. */

/* Open/create a database. Returns a handle (>=0) or -1 on error. */
__attribute__((import_module("hal"), import_name("db_open")))
int32_t hal_db_open(const char *path, uint32_t path_len);

/* Run a non-SELECT statement (CREATE/INSERT/UPDATE/DELETE/BEGIN/COMMIT).
 * Returns 0 on success, -1 on error (see hal_db_error). */
__attribute__((import_module("hal"), import_name("db_exec")))
int32_t hal_db_exec(int32_t handle, const char *sql, uint32_t sql_len,
                    const char *params_json, uint32_t params_len);

/* Run a SELECT and write the result rows as a JSON array into out.
 * Returns bytes written (>=0), -1 on SQL error, or -2 if the buffer is
 * too small (retry with a larger one; use LIMIT to bound results). */
__attribute__((import_module("hal"), import_name("db_query")))
int32_t hal_db_query(int32_t handle, const char *sql, uint32_t sql_len,
                     const char *params_json, uint32_t params_len,
                     char *out, uint32_t out_cap);

/* Write the last error message for a handle into out. Returns bytes. */
__attribute__((import_module("hal"), import_name("db_error")))
uint32_t hal_db_error(int32_t handle, char *out, uint32_t out_cap);

/* Close a database handle and release its resources. */
__attribute__((import_module("hal"), import_name("db_close")))
void hal_db_close(int32_t handle);

/* ── Generic crypto (caller-supplied keys) ──────────────────────────── *
 *
 * The hal_identity_* / hal_encrypt / hal_decrypt calls all use THIS device's
 * profile key. These complementary calls operate on keys the wapp itself
 * holds — needed for things like a group/room key independent of any one
 * member. Keys and signatures are lowercase hex strings; messages and AES
 * payloads are raw bytes. Signing hashes the message with SHA-256 first
 * (BIP-340 Schnorr over secp256k1), matching hal_identity_sign. */

/* Generate a fresh secp256k1 keypair. Writes JSON {"priv":hex,"pub":hex}
 * (pub is the 32-byte x-only key). Returns bytes written, 0 on error. */
__attribute__((import_module("hal"), import_name("crypto_keygen")))
uint32_t hal_crypto_keygen(char *out, uint32_t out_cap);

/* Sign msg with priv_hex; write the signature hex. Returns bytes, 0 on error. */
__attribute__((import_module("hal"), import_name("crypto_sign")))
uint32_t hal_crypto_sign(const char *priv_hex, uint32_t priv_len,
                         const char *msg, uint32_t msg_len,
                         char *out, uint32_t out_cap);

/* Verify sig_hex on msg for pub_hex. Returns 1 if valid, 0 otherwise. */
__attribute__((import_module("hal"), import_name("crypto_verify")))
int32_t hal_crypto_verify(const char *pub_hex, uint32_t pub_len,
                          const char *sig_hex, uint32_t sig_len,
                          const char *msg, uint32_t msg_len);

/* Fill out with out_len cryptographically-random bytes. Returns bytes written. */
__attribute__((import_module("hal"), import_name("crypto_random")))
uint32_t hal_crypto_random(char *out, uint32_t out_len);

/* AES-256-CBC encrypt `in` under the 32-byte `key`. A random IV is
 * generated and prepended to the ciphertext. Returns bytes written, 0 on
 * error (e.g. key not 32 bytes or out too small). */
__attribute__((import_module("hal"), import_name("crypto_aes_encrypt")))
uint32_t hal_crypto_aes_encrypt(const char *key, uint32_t key_len,
                                const char *in, uint32_t in_len,
                                char *out, uint32_t out_cap);

/* Decrypt a blob produced by hal_crypto_aes_encrypt (IV || ciphertext)
 * under the 32-byte `key`. Returns plaintext bytes written, 0 on error. */
__attribute__((import_module("hal"), import_name("crypto_aes_decrypt")))
uint32_t hal_crypto_aes_decrypt(const char *key, uint32_t key_len,
                                const char *in, uint32_t in_len,
                                char *out, uint32_t out_cap);

/* ── Reticulum (wapp-scoped peer-to-peer datagrams) ─────────────────── *
 *
 * Exchange opaque datagrams with other devices running the SAME wapp over
 * the device's shared Reticulum node. Traffic is demultiplexed by the
 * calling wapp, so different wapps never see each other's datagrams. A
 * datagram is delivered to every reachable peer (the RNS mesh: LAN, BLE,
 * and transport peers); on a LAN/BLE link it travels device-to-device,
 * and where peers are only reachable through a transport node it transits
 * that node but the payload is whatever bytes the wapp put in — encrypt
 * end-to-end before sending. Payloads must fit one packet (a few hundred
 * bytes); chunk anything larger. */

/* This device's RNS destination hash (hex) — usable as a sender id so a
 * peer can tell datagrams apart. Returns bytes written, 0 if node down. */
__attribute__((import_module("hal"), import_name("rns_identity")))
uint32_t hal_rns_identity(char *out, uint32_t out_cap);

/* Broadcast `payload` to all reachable peers running this wapp. Returns 1
 * if queued, -1 on error (node down / payload too large). */
__attribute__((import_module("hal"), import_name("rns_broadcast")))
int32_t hal_rns_broadcast(const char *payload, uint32_t payload_len);

/* Reliably deliver `payload` ADDRESSED to one peer's RNS delivery dest (hex,
 * from hal_rns_delivery_dest). Direct if reachable, else held for the peer to
 * pull (store-and-forward) — tolerant of NAT/asymmetric inbound. The peer
 * receives it on the same queue as hal_rns_recv. Returns 1 if queued, -1 err. */
__attribute__((import_module("hal"), import_name("rns_send_to")))
int32_t hal_rns_send_to(const char *dest_hex, uint32_t dest_len,
                        const char *payload, uint32_t payload_len);

/* Pull store-and-forwarded datagrams a peer is holding for us, from its
 * propagation dest (hex, from hal_rns_prop_dest). Fire-and-forget; pulled
 * datagrams arrive via hal_rns_recv. Returns 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("rns_pull")))
int32_t hal_rns_pull(const char *prop_dest_hex, uint32_t dest_len);

/* This device's LXMF delivery dest hash (hex) — give to peers so they can
 * hal_rns_send_to us. Returns bytes written, 0 if node down. */
__attribute__((import_module("hal"), import_name("rns_delivery_dest")))
uint32_t hal_rns_delivery_dest(char *out, uint32_t out_cap);

/* This device's LXMF propagation (mailbox) dest hash (hex) — give to peers so
 * they can hal_rns_pull from us. Returns bytes written, 0 if node down. */
__attribute__((import_module("hal"), import_name("rns_prop_dest")))
uint32_t hal_rns_prop_dest(char *out, uint32_t out_cap);

/* Short-code rendezvous (discovery without a directory). Announce a rendezvous
 * destination derived from the public [seed] (e.g. a circle short code) carrying
 * [app_data] (our address + the full id), so a peer holding only the seed can
 * find us. Owners call this periodically. Returns 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("rns_rv_announce")))
int32_t hal_rns_rv_announce(const char *seed, uint32_t seed_len,
                            const char *app_data, uint32_t app_len);

/* Resolve the rendezvous for [seed]: path-requests the derived dest and writes
 * the announced app_data into [out]. Returns bytes written, or 0 while pending
 * (call again to poll — the first call kicks off the async resolve). */
__attribute__((import_module("hal"), import_name("rns_rv_resolve")))
uint32_t hal_rns_rv_resolve(const char *seed, uint32_t seed_len,
                            char *out, uint32_t out_cap);

/* Send [payload] to the rendezvous dest derived from [seed] as ONE encrypted
 * connectionless packet (the owner listens there). First-contact channel that
 * needs no link handshake, so it survives a flaky owner inbound. */
__attribute__((import_module("hal"), import_name("rns_rv_send")))
int32_t hal_rns_rv_send(const char *seed, uint32_t seed_len,
                        const char *payload, uint32_t payload_len);

/* Size of the next inbound datagram JSON envelope, 0 if none pending. */
__attribute__((import_module("hal"), import_name("rns_available")))
uint32_t hal_rns_available(void);

/* Read the next inbound datagram as JSON {"from":hex,"payload":base64,
 * "ts":ms} into out. Returns bytes written, 0 if none. */
__attribute__((import_module("hal"), import_name("rns_recv")))
uint32_t hal_rns_recv(char *out, uint32_t out_cap);

/* ── NOSTR-relay store-and-forward DM backup (kind-4 over Reticulum) ──────── *
 *
 * Back up 1:1 messages to up to 3 NOSTR relays reachable over Reticulum. The
 * host owns the active profile key and does the NOSTR work (BIP-340 signing,
 * NIP-04 encryption/decryption, publish/query/delete); the wapp supplies the
 * recipient npub (base64url, as hal_identity_pubkey returns) + plaintext and
 * orchestrates which relays to use + when to poll/clean up. */

/* Up to 3 reachable relays (their RNS identity hashes, hex) as a JSON array of
 * strings. Returns bytes written, 0 if none/too small. */
__attribute__((import_module("hal"), import_name("relay_reachable")))
uint32_t hal_relay_reachable(char *out, uint32_t out_cap);

/* Publish [text] (plaintext) as a kind-4 (NIP-04) encrypted DM to recipient
 * [npub] (base64url x-only pubkey), signed by this device's profile key, to each
 * relay in [relays_json] (a JSON array of relay hashes). [mid] is carried in a
 * `d` tag so the recipient can dedup the relay copy against the direct copy.
 * Fire-and-forget; returns 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("relay_dm_send")))
int32_t hal_relay_dm_send(const char *npub, uint32_t npub_len,
                          const char *text, uint32_t text_len,
                          const char *relays_json, uint32_t relays_len,
                          const char *mid, uint32_t mid_len);

/* Trigger an async fetch of kind-4 DMs addressed to us with created_at >=
 * [since_sec] from [relays_json] (JSON array of relay hashes). Decrypted results
 * arrive on the same queue hal_relay_dm_recv drains. Returns 1 if queued. */
__attribute__((import_module("hal"), import_name("relay_dm_fetch")))
int32_t hal_relay_dm_fetch(uint32_t since_sec,
                           const char *relays_json, uint32_t relays_len);

/* Rendezvous relay set for [pubkey] (hex or base64url x-only): JSON array of
 * relay identity hashes ranked by sha256(relay|pubkey). Sender (recipient's
 * key) and receiver (own key) derive the SAME set independently, so the
 * publish and poll sets meet even when the ?RLY announce was missed. */
__attribute__((import_module("hal"), import_name("relay_for")))
int32_t hal_relay_for(const char *pubkey, uint32_t pubkey_len,
                      char *out, uint32_t out_cap);

/* Pop the next fetched DM as JSON {"id":hex,"from":base64url,"ts":sec,
 * "text":plaintext,"mid":id} into out. Returns bytes written, 0 if none. */
__attribute__((import_module("hal"), import_name("relay_dm_recv")))
uint32_t hal_relay_dm_recv(char *out, uint32_t out_cap);

/* Recipient-authorized delete of received DMs [ids_json] (JSON array of event
 * ids) from [relays_json]. Fire-and-forget; returns 1 if queued. */
__attribute__((import_module("hal"), import_name("relay_dm_drop")))
int32_t hal_relay_dm_drop(const char *ids_json, uint32_t ids_len,
                          const char *relays_json, uint32_t relays_len);

/* Publish OUR identity (callsign -> npub + Reticulum delivery/propagation dests)
 * to [relays_json] as a signed, replaceable kind-30078 event, so peers can
 * resolve us by callsign. Fire-and-forget; returns 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("relay_identity_publish")))
int32_t hal_relay_identity_publish(const char *callsign, uint32_t callsign_len,
                                   const char *deliv, uint32_t deliv_len,
                                   const char *prop, uint32_t prop_len,
                                   const char *relays_json, uint32_t relays_len);

/* Trigger an async resolve of [callsign] -> npub by querying [relays_json] for
 * the identity event. The result (if any) lands on the queue
 * hal_relay_resolve_recv drains. Returns 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("relay_resolve")))
int32_t hal_relay_resolve(const char *callsign, uint32_t callsign_len,
                          const char *relays_json, uint32_t relays_len);

/* Pop the next resolution as JSON {callsign, npub(base64url), deliv, prop}.
 * Returns bytes written, 0 if none queued or the buffer is too small. */
__attribute__((import_module("hal"), import_name("relay_resolve_recv")))
uint32_t hal_relay_resolve_recv(char *out, uint32_t out_cap);

/* ── hal.nostr — transport-abstract NOSTR client ─────────────────────────
 *
 * A normal NOSTR client, but the transport is chosen by each relay URI's
 * scheme, so the wapp never cares which medium a relay is on:
 *   wss:// | ws://   internet WebSocket
 *   rns://<idhash>   a relay on the Reticulum mesh
 *   local            THIS device (also served to others over RNS + a local
 *                    wss server, so the device is itself a relay + Blossom).
 * Every inbound event merges into the one local store; subscriptions are
 * drained one event at a time (inbox-pop). The host holds the profile key and
 * signs on hal_nostr_post — the nsec never enters the wasm sandbox. */

/* ── LXMF (Reticulum's own messaging: NomadNet, Sideband, …) ──────────────
 * A XPRS group rides NOSTR, but the Reticulum world already has its own chat,
 * and those people are on the same mesh.
 *
 * THERE IS NO hal_lxmf_recv. It was a cursor over the host's entire LXMF
 * inbox -- every private message on the device, with no recipient test -- and
 * a second receive door besides: the same message reached a wapp both there
 * and on the event bus, with a cursor that restarted at zero on every engine.
 * A message arrives once now, from the core, on `xprs.message`. Foreign LXMF
 * (a NomadNet or Sideband peer writing plain text) is refused at the host's
 * inbox door and reaches no wapp at all.
 *
 * NOR IS THERE A SEND SIDE. `lxmf_send` and `lxmf_send2` named ONE Reticulum
 * destination, which is a wapp choosing a transport -- and choosing the one
 * transport that cannot reach a station standing in the same room.
 *
 * hal_xprs_message replaced both: the wapp gives the words and the recipient,
 * the core seals (9.2), signs, splits (6.6), ranks the bearers (12.0), parks a
 * custody copy and hands back the section 5 identifier. */

/* Relay list + live status as JSON [{"uri","scheme","status"}]. Returns bytes
 * written, or the negated required size if [out] is too small. */
__attribute__((import_module("hal"), import_name("nostr_relays")))
uint32_t hal_nostr_relays(char *out, uint32_t out_cap);

/* Add/remove a relay by URI (wss://…, rns://<idhash>, local). 1 on success. */
__attribute__((import_module("hal"), import_name("nostr_relay_add")))
int32_t hal_nostr_relay_add(const char *uri, uint32_t uri_len);
__attribute__((import_module("hal"), import_name("nostr_relay_remove")))
int32_t hal_nostr_relay_remove(const char *uri, uint32_t uri_len);

/* Open a subscription from a NIP-01 [filter] (JSON object or array of them),
 * fanned across every enabled relay + the local store. Writes the opaque subId
 * into [out]; returns its byte length, 0 on error. */
__attribute__((import_module("hal"), import_name("nostr_subscribe")))
uint32_t hal_nostr_subscribe(const char *filter, uint32_t filter_len,
                             char *out, uint32_t out_cap);

/* Pop the next buffered event JSON (NIP-01 event object) for subscription [sub]
 * into [out]. Returns bytes written, 0 when the inbox is drained. Poll each
 * tick. */
__attribute__((import_module("hal"), import_name("nostr_event_recv")))
uint32_t hal_nostr_event_recv(const char *sub, uint32_t sub_len,
                              char *out, uint32_t out_cap);

/* Close a subscription. */
__attribute__((import_module("hal"), import_name("nostr_unsubscribe")))
int32_t hal_nostr_unsubscribe(const char *sub, uint32_t sub_len);

/* Build a NOSTR event of [kind] with [content] and [tags] (JSON array of tag
 * arrays), sign it with the active profile key (host-side), and publish to the
 * local store + every enabled relay. Fire-and-forget: the event appears on the
 * feed's next hal_nostr_event_recv drain. */
__attribute__((import_module("hal"), import_name("nostr_post")))
int32_t hal_nostr_post(int32_t kind, const char *content, uint32_t content_len,
                       const char *tags, uint32_t tags_len);

/* Followed pubkeys (hex) as a JSON array — who the user explicitly follows. */
__attribute__((import_module("hal"), import_name("nostr_follows")))
uint32_t hal_nostr_follows(char *out, uint32_t out_cap);

/* Web-of-trust author set as a JSON array (hex): the user's follows, the people
 * who follow them, and their follows' follows (degree-2), capped. Subscribe the
 * feed to kind-1 from THIS instead of the global firehose to cut spam. Grows as
 * kind-3 contact lists arrive, so re-read it periodically. */
__attribute__((import_module("hal"), import_name("nostr_wot")))
uint32_t hal_nostr_wot(char *out, uint32_t out_cap);

/* POPULAR feed: writes a subscription id that only yields kind-1 posts which
 * have gathered more than 2 distinct reactions. Note what this means — a post
 * cannot appear here until it is old enough to have COLLECTED those likes, so
 * this feed is always behind. It is a "what is worth reading" feed, never a
 * "what is happening" one. Drain with hal_nostr_event_recv like any other sub.
 * Returns subId byte length, 0 if unavailable. */
__attribute__((import_module("hal"), import_name("nostr_discovery")))
uint32_t hal_nostr_discovery(char *out, uint32_t out_cap);

/* LIVE firehose: kind-1 as the relays push it, within a second of being posted.
 * This is the feed of STRANGERS — the way a user finds accounts worth following.
 *
 * The host applies a quality gate before anything reaches you (hashtag walls,
 * link-only adverts, copy-paste bot rings, flooding authors, muted accounts, and
 * authors with no profile at all). Your own posts and the people you follow are
 * never filtered. Drain with hal_nostr_event_recv like any other sub.
 * Returns subId byte length, 0 if unavailable. */
__attribute__((import_module("hal"), import_name("nostr_firehose")))
uint32_t hal_nostr_firehose(char *out, uint32_t out_cap);

/* Engagement counts for a post: writes JSON {"likes":N,"replies":M,"mine":bool}
 * for event [id]. 0/0/false until the host has seen reactions/replies for it
 * (call hal_nostr_track first so it subscribes to them). */
__attribute__((import_module("hal"), import_name("nostr_stats")))
uint32_t hal_nostr_stats(const char *id, uint32_t id_len,
                         char *out, uint32_t out_cap);

/* Track post [ids] (JSON array of event ids) so the host subscribes to and
 * counts their reactions (kind-7) and replies (kind-1 #e). Rolling window. */
__attribute__((import_module("hal"), import_name("nostr_track")))
int32_t hal_nostr_track(const char *ids, uint32_t ids_len);

/* Author profile for [pubkey] (hex): writes JSON
 * {"name","pic","about","nip05","npub"} from its kind-0 metadata. Empty name
 * until the kind-0 arrives — calling this also subscribes to (fetches) it, so
 * poll again shortly. */
__attribute__((import_module("hal"), import_name("nostr_profile")))
uint32_t hal_nostr_profile(const char *pubkey, uint32_t pubkey_len,
                           char *out, uint32_t out_cap);

/* Like [id]: publish a signed kind-7 '+' reaction referencing it. */
__attribute__((import_module("hal"), import_name("nostr_react")))
int32_t hal_nostr_react(const char *id, uint32_t id_len);

/* Repost [id] (kind-6 "retweet"): publish a signed kind-6 tagged e=id, p=author. */
__attribute__((import_module("hal"), import_name("nostr_repost")))
int32_t hal_nostr_repost(const char *id, uint32_t id_len,
                         const char *author, uint32_t author_len);

/* Reply to [parent]: publish a signed kind-1 note tagged e=parent. */
__attribute__((import_module("hal"), import_name("nostr_reply")))
int32_t hal_nostr_reply(const char *parent, uint32_t parent_len,
                        const char *text, uint32_t text_len);

/* Stored replies to post [id]: writes JSON [{"id","pubkey","content","ts"}]
 * (kind-1 events that #e it). Returns bytes written, or the negated required
 * size if [out] is too small. */
__attribute__((import_module("hal"), import_name("nostr_replies")))
uint32_t hal_nostr_replies(const char *id, uint32_t id_len,
                           char *out, uint32_t out_cap);

/* Follow / unfollow a pubkey ([key] hex or npub). */
__attribute__((import_module("hal"), import_name("nostr_follow")))
int32_t hal_nostr_follow(const char *key, uint32_t key_len);
__attribute__((import_module("hal"), import_name("nostr_unfollow")))
int32_t hal_nostr_unfollow(const char *key, uint32_t key_len);

/* Our own x-only pubkey (hex) into [out]; use it to build the Messages filter
 * {"kinds":[4],"#p":[<self>]}. Returns bytes written, 0 if no profile. */
__attribute__((import_module("hal"), import_name("nostr_self")))
uint32_t hal_nostr_self(char *out, uint32_t out_cap);

/* Encrypt [text] (NIP-04) to [recipient] (hex x-only pubkey), sign it as a
 * kind-4 with the profile key, and publish across every enabled relay.
 * Fire-and-forget; 1 if queued, -1 on error. */
__attribute__((import_module("hal"), import_name("nostr_dm_send")))
int32_t hal_nostr_dm_send(const char *recipient, uint32_t recipient_len,
                          const char *text, uint32_t text_len);

/* Decrypt a kind-4 [content] sent by [sender] (hex x-only pubkey) with the
 * profile key. Writes plaintext to [out]; returns bytes written, 0 if it is
 * not addressed to us / cannot be decrypted. */
__attribute__((import_module("hal"), import_name("nostr_dm_decrypt")))
uint32_t hal_nostr_dm_decrypt(const char *sender, uint32_t sender_len,
                              const char *content, uint32_t content_len,
                              char *out, uint32_t out_cap);

/* ── Reticulum visualization/management (read-only) ──────────────────── *
 *
 * The node's view of the Reticulum network, for the "reticulum" wapp to
 * render an interactive graph. This is an OBSERVED, sampled view (the nodes
 * whose announces this node has heard) — never a hub's full client roster.
 * Each returns the number of bytes written; when the JSON does not fit, the
 * NEGATED required length is returned (nothing written) so the caller can
 * retry with a larger buffer. Config (add/remove/connect hubs, passive
 * toggle) is performed by emitting host-action messages, not via the HAL. */

/* Node status JSON ({up,mode,identity,paths,passive,observed,...}). */
__attribute__((import_module("hal"), import_name("rns_status")))
int32_t hal_rns_status(char *out, uint32_t out_cap);

/* Configured bootstrap hubs as a JSON array
 * [{"endpoint":"host:port","connected":bool},...]. */
__attribute__((import_module("hal"), import_name("rns_hubs")))
int32_t hal_rns_hubs(char *out, uint32_t out_cap);

/* The observed network as a {"nodes":[...],"edges":[...],"sample":true}
 * graph. [filter] is an optional JSON object
 * {"service":str,"xprsOnly":bool,"search":str,"role":str} (pass len 0 for
 * none). "role" buckets a node by what it serves: "super" (a super-archiver,
 * XPRS.md 12.9.4), "archive" (an archiver that is not a super), or "normal"
 * (neither). An unrecognised value filters nothing. */
__attribute__((import_module("hal"), import_name("rns_nodes")))
int32_t hal_rns_nodes(const char *filter, uint32_t filter_len,
                      char *out, uint32_t out_cap);



/* ── BLE street mesh (doc/mesh.md) ──────────────────────────────── *
 *
 * Read-only registry of the BLE mesh node: who is within reach (direct
 * neighbors heard over route beacons) and which destinations are reachable
 * multi-hop, plus this node's own status. Overflow protocol: when the JSON
 * doesn't fit, the NEGATED required size is returned and nothing is written. */

/* ── hal.node — the Archiver role (docs/NOSTR.md) ───────────────────────────
 * A role a person GRANTS, INSPECTS and REVOKES. An archiver answers "where can I
 * find npub X"; it holds pointers, never other people's posts.
 */
__attribute__((import_module("hal"), import_name("node_status")))
int32_t hal_node_status(char *out, uint32_t out_cap);

__attribute__((import_module("hal"), import_name("node_peers")))
int32_t hal_node_peers(char *out, uint32_t out_cap);

__attribute__((import_module("hal"), import_name("node_set_pref")))
int32_t hal_node_set_pref(const char *kv, uint32_t kv_len);

__attribute__((import_module("hal"), import_name("node_maint")))
int32_t hal_node_maint(char *out, uint32_t out_cap);

__attribute__((import_module("hal"), import_name("node_sweep")))
int32_t hal_node_sweep(const char *id, uint32_t id_len);

/* ── hal.archive — the Archiver role ──────────────────────────────────────
 * Storage volunteered for other people, with a quota the owner chose and a
 * visible, deletable list of what is being held.
 */
__attribute__((import_module("hal"), import_name("archive_status")))
int32_t hal_archive_status(char *out, uint32_t out_cap);

__attribute__((import_module("hal"), import_name("archive_items")))
int32_t hal_archive_items(char *out, uint32_t out_cap);

__attribute__((import_module("hal"), import_name("archive_drop")))
int32_t hal_archive_drop(const char *sha, uint32_t sha_len);

__attribute__((import_module("hal"), import_name("archive_set_pref")))
int32_t hal_archive_set_pref(const char *kv, uint32_t kv_len);


/* XPRS: what this device has heard ON THE AIR (docs/XPRS.md).
 *
 * Read-only diagnostics. Internet traffic is NOT here and cannot be: the host
 * records the bearer where a packet arrives and only collects radio and local
 * ones, so there is nothing to filter out and nothing to forget to filter.
 *
 * Stations heard, as ready-to-render people-widget sections -- up to three:
 * in earshot now (heard within the last eleven minutes on a radio or the
 * local network -- the same table every reachability decision in the core
 * reads; a station heard through a relay counts, the radio is what it
 * arrived on), then heard this hour but quiet since, then XPRS stations
 * whose packets reached us over Reticulum this hour and were not heard on
 * the air at all. Each newest first; an empty section is omitted. Every row
 * carries a `seen Xs/Xm ago` tag first and the bearer (or RNS) second.
 *   [{"title":"Heard over the air (n)","items":[{id,title,subtitle,tags}]},
 *    {"title":"Heard this hour (m)","items":[...]},
 *    {"title":"On Reticulum (k)","items":[...]}]
 * Each item also carries "kind": "user", "station" or "device" (XPRS.md 3,
 * decided by the core: a wapp listing devices reads it, never a prefix). */
__attribute__((import_module("hal"), import_name("xprs_stations")))
int32_t hal_xprs_stations(char *out, uint32_t out_cap);

/* What another station offers through its visitor API (spec/API-HTTP.md):
 * the same rooms, galleries, music and libraries its web page shows, read as
 * this profile (so the private rooms it belongs to are there too).
 *
 * The answer is what the last visit learned, at once; when there is none, or
 * none recent, the core visits the station and publishes `core.station`:
 * subscribe to it while the screen is open and read again. The wapp never
 * says how the station is reached.
 *
 * Request (JSON): {"call":"X3PTZM","get":"offers"}
 *                 {"call":..,"get":"folders","room":"X5.."}
 *                 {"call":..,"get":"items","room":"X5..","folder":"<id>","offset":0}
 *                 {"call":..,"get":"forget"}        (the screen closed)
 * Every answer: "state":"loading|ready|failed", "busy":bool, "why" when
 * failed (unknown = it never announced an API, unreached, refused, or what
 * was wrong with its proof).
 *   offers:  "serve":[..], "tabs":[..], "known":bool (the station accepted
 *            this profile's key), "rooms":[{"call","name","about",
 *            "kind":"chat|forum|gallery|music|library|mesh","private":bool,
 *            "role","can_post","members"}]
 *   folders: "folders":[{"id","title","count","cover"}]
 *   items:   "total","offset","items":[{"id","caption","name","size","from",
 *            "ts","likes","liked","preview","file"}], 60 at most per read
 *   list (get:"list", no call; "scope":"local|regional|global|all",
 *            "search", "offset"): the stations themselves, 60 per read,
 *            nearest class and newest first: "counts":{"local","regional",
 *            "global","all"}, "total", "offset", "rows":[{"call","kind",
 *            "reach","bearers":[..],"age_s","api":bool (it offers this API),
 *            "hops" and "dist_m" when known}]. Read it on core.monitor and
 *            core.rns.graph. Scope is the class of the nearest bearer a
 *            station is heard on (XPRS.md 9.11), decided by the core.
 *   ways (get:"ways"): how a message from here gets to that station, to
 *            SHOW, never to decide from: "self", "routes":[{"sure":bool,
 *            "hops":[{"from","to","bearer","reach":"local|regional|global",
 *            "know","age_s","rssi"}]}]. Each hop is "to" hearing "from" over
 *            that bearer, and "know" says how that is known: heard (this
 *            device heard it), asked (the hearing station answered when
 *            asked), said (it disclosed it in its beacon), guess (inferred:
 *            draw it as a guess; "?" names a station nobody named). "sure" is
 *            false when any hop is a guess. The core asks the hearing
 *            stations in the background and publishes core.station.
 * cover, preview and file are media tokens ("" when none): hal_media_fetch
 * gets them from that station, hal_media_state follows it, hal_media_open
 * shows it.
 * Returns the bytes written, 0 on a bad request, or the negated size needed.  * `{"get":"host"}` (no `call`): this device as a station:
 * `{call, serving, share:{busy, done, total, failed}}`. Its own callsign is
 * browsed like any other; `hal_xprs_set_pref("hostStation=1|0")` says
 * whether visitors are answered, and the host message
 * `{"type":"station.share","kind":"gallery"|"music"|"library"}` lets the
 * person pick a folder to share.
 */
__attribute__((import_module("hal"), import_name("station_read")))
int32_t hal_station_read(const char *req, uint32_t req_len,
                         char *out, uint32_t out_cap);

/* One station, everything the host holds about it this hour, flat:
 *   {"call","kind","bearer","bearers":[..],"rssi","lastMs","agoMs",
 *    "lastDirectMs","packets", and when it has said so: "peers","mail",
 *    "uptime","lifetime","fw","count","serve":[..],"hears":[..],"sig",
 *    "readings":{k:v}, "npub", "pos", "acc"}
 * pos and acc are where the station says it is (its beacon's pos:/acc:,
 * already coarsened by its owner), absent when it shares no position.
 * uptime and lifetime are the qty text as aired ("26h", "38day"); sig is the
 * headline verdict of its signatures (verified, unverified, forged, unsigned).
 * readings holds the latest of each measurement key (weather, telemetry,
 * energy, and a device's state/level/target/volt), as aired with its unit,
 * the newest COMPOSED value per key. npub is the station's key when the core
 * holds one for it (from its t:identity): what hal_encrypt seals to, for a
 * station this wapp never heard ask to be claimed.
 * Returns the bytes written, 0 when the host has not heard it this hour, or
 * the negated size needed when out_cap is too small. */
__attribute__((import_module("hal"), import_name("xprs_station")))
int32_t hal_xprs_station(const char *call, uint32_t call_len, char *out, uint32_t out_cap);

/* Where THIS station says it is, exactly as its beacon says it: the owner's
 * shared position (Settings > Privacy), already coarsened to the radius they
 * chose (XPRS.md 15.1 decimals, 15.2 acc):
 *   {"pos":"38.7077,-9.1365","acc":10}
 * Returns the bytes written, 0 when the owner shares no position (sharing off,
 * or no fix and no position set), or the negated size needed when out_cap is
 * too small. A wapp that states a place for this station uses this, never a
 * finer position of its own. */
__attribute__((import_module("hal"), import_name("xprs_position")))
int32_t hal_xprs_position(char *out, uint32_t out_cap);

/* Who is there by name (XPRS.md 12.9.4): people, stations and groups known
 * by a verified t:identity, heard here or replayed by the archivers the core
 * asks. [query] is JSON {"q":"text","kind":"group|user|station|","limit":n,
 * "ask":true}; `q` matches any part of the callsign or the name, any case
 * (`_` and `-` read as spaces); `ask` lets the core ask its archivers for
 * names now, which it bounds. Subscribe to `core.names` to read again when
 * names arrive. Reply, newest first: [{call,nick,kind,ts}], `kind` group,
 * user or station, `ts` epoch seconds of its last announcement. Bytes
 * written, negated size if `out` is small. */
__attribute__((import_module("hal"), import_name("xprs_names")))
int32_t hal_xprs_names(const char *query, uint32_t query_len,
                       char *out, uint32_t out_cap);

/* What an ADDRESS names, by the core's one rule: "user" (X1), "station" (X2,
 * X3 or a licence), "device" (X4), "foreign" (a node of another network,
 * MT/MC and eight hex, XPRS.md 3.2), "closed" (an X5 closed group) or "open"
 * (an open group's name, 7.3: LISBOA). A wapp filing a conversation asks
 * this rather than testing a prefix of its own. A node of another network
 * (3.2) carries that network after a colon, `foreign:meshtastic` or
 * `foreign:meshcore`, which is the longest answer there is: give it 32
 * bytes, and read only the head of the word if the network is not your
 * business. Returns the bytes written, 0 for an empty address, or the
 * negated size needed. Not gated. */
__attribute__((import_module("hal"), import_name("xprs_kind")))
int32_t hal_xprs_kind(const char *addr, uint32_t addr_len, char *out, uint32_t out_cap);

/* Follow (on=1) or stop following (on=0) a station by its CALLSIGN (XPRS.md
 * 12's middle tier), for what has no person's key to follow: a device found
 * nearby or in the archive. Its packets are then kept, observations included,
 * and while it is out of earshot the core asks this station's chosen
 * archivers for it (12.12.2). An open group's name ("PICNIC", 7.3) is
 * followed as a room: its talk is kept and asked for, so somebody who joins
 * sees what was said before. The wapp is told none of that; it reads the
 * archive. 0, or -1 for an empty, malformed or group (X5) callsign.
 * Permission archive.read. */
__attribute__((import_module("hal"), import_name("xprs_follow")))
int32_t hal_xprs_follow(const char *call, uint32_t call_len, int32_t on);

/* Follow (on=1) or stop following (on=0) a packet TYPE, by its t: word
 * ("event", "poll", ...): its undirected publications are kept from anyone,
 * those this station hears and those its chosen archivers replay, in the one
 * archive, one row per packet; the core asks the archivers for what is new
 * of it (`cmd:history kind:<type> since:<newest held>`, XPRS.md 11.2) on its
 * own cadence. The wapp reads hal_xprs_history and is told none of how a row
 * got there. Per wapp: another wapp following the same type is unaffected.
 * 0, or -1 for a word that is not a packet type. Permission archive.read. */
__attribute__((import_module("hal"), import_name("xprs_follow_kind")))
int32_t hal_xprs_follow_kind(const char *kind, uint32_t kind_len, int32_t on);

/* The stations followed by callsign: a JSON array of bare callsigns,
 * ["X4PL3M",...]. Bytes written, or the negated size needed. Permission
 * archive.read. */
__attribute__((import_module("hal"), import_name("xprs_followed")))
int32_t hal_xprs_followed(char *out, uint32_t out_cap);

/* Ask what is in local reach to identify itself now (XPRS.md 8, 29.1:
 * q:identity asks "directly rather than waiting for the next period"),
 * instead of waiting for its next beacon. Where to ask is the core's: today
 * every host on the local network, over UDP 4242. The answers are ordinary
 * packets and appear in hal_xprs_stations; core.monitor says when. 1 when
 * the core asked, 0 when it did not (no local network, no callsign yet, or
 * it asked within the last 30 s). */
__attribute__((import_module("hal"), import_name("xprs_discover")))
int32_t hal_xprs_discover(void);

/* ── Flashing a board over USB (permission device.flash) ─────────────────
 * The serial port, the ESP ROM loader, the catalogue (xprs.dev/firmware)
 * and the downloaded images are the core's. A wapp asks with the verbs
 * below, every one fire-and-forget answering 1 when it started, and hears
 * `core.flash` {topic,rev} whenever anything moved: a device plugged in, a
 * probe answered, a download or a write advanced, a session ended. It then
 * reads hal_flash_state once. */

/* List the USB serial devices; refresh the catalogue when it is stale.
 * 0 on a platform without USB serial. */
__attribute__((import_module("hal"), import_name("flash_scan")))
int32_t hal_flash_scan(void);

/* Put the board on [device] into its loader and read the chip, its flash
 * size and the firmware it runs; the state then carries device.chip,
 * device.flashBytes, device.runs, device.suggested and device.likely.
 * The board restarts afterwards. 0 when busy or unknown. */
__attribute__((import_module("hal"), import_name("flash_probe")))
int32_t hal_flash_probe(const char *device, uint32_t device_len);

/* Download a board's parts (manifest.json and its bins) and check them. */
__attribute__((import_module("hal"), import_name("flash_fetch")))
int32_t hal_flash_fetch(const char *board, uint32_t board_len);

/* Write the downloaded [board] to [device], each part verified by the
 * ROM's MD5. wipe=1 erases the NVS and OTA data partitions first: a new
 * station with no key, owner or WiFi. 0 when busy or not downloaded. */
__attribute__((import_module("hal"), import_name("flash_write")))
int32_t hal_flash_write(const char *device, uint32_t device_len,
                        const char *board, uint32_t board_len, int32_t wipe);

/* Stop the session that runs. */
__attribute__((import_module("hal"), import_name("flash_cancel")))
int32_t hal_flash_cancel(void);

/* Everything, flat:
 *   {"phase":idle|scanning|probing|fetching|writing|verifying|done|failed,
 *    "busy","message","error","supported",
 *    "devices":[{"id","port","product","manufacturer","serial","vid","pid",
 *                "permitted","nativeUsb"}],
 *    "boards":[{"id","name","vendor","family","flashMb","psramMb","port",
 *               "env","image","version","status","flashable",
 *               "local" (the downloaded version or ""),"localBytes"}],
 *    "device":{...the probed device, plus "chip","chipLabel","flashBytes",
 *              "runs","runsVersion","suggested","likely" (ids, space-joined)},
 *    "board","part","partIndex","partCount","done","total"}
 * Returns the bytes written, or the negated size needed. */
__attribute__((import_module("hal"), import_name("flash_state")))
int32_t hal_flash_state(char *out, uint32_t out_cap);

/* Recent XPRS packets, oldest first. INCLUDES packets addressed to other
 * stations, which is most of what a mesh carries:
 *   [{ts,bearer,rssi,from,to,type,id,mine,wire}]
 * `bearer` is one of ble|lan|lora|wifi|vhf|uhf|hf; `mine` is whether `d:`
 * named this station. */
__attribute__((import_module("hal"), import_name("xprs_traffic")))
int32_t hal_xprs_traffic(char *out, uint32_t out_cap);

/* Mesh node status JSON
 * ({running,callsign,advertising,class,powered,uptime,neighbors,routes,
 *   beaconsSent,beaconsHeard,revision}). */
__attribute__((import_module("hal"), import_name("mesh_status")))
int32_t hal_mesh_status(char *out, uint32_t out_cap);

/* Devices within reach as ready-to-render people-widget sections
 * [{"title":"Nearby (n)","items":[{id,title,subtitle,tags,...}]},
 *  {"title":"Multi-hop (n)","items":[...]}]. */
__attribute__((import_module("hal"), import_name("mesh_devices")))
int32_t hal_mesh_devices(char *out, uint32_t out_cap);

/* Custody store + bulk spool counters JSON (M2/M3). */
__attribute__((import_module("hal"), import_name("mesh_scf_status")))
int32_t hal_mesh_scf_status(char *out, uint32_t out_cap);

/* Bulk transfers JSON [{sha,name,target,size,have,state,active}]. */
__attribute__((import_module("hal"), import_name("mesh_transfers")))
int32_t hal_mesh_transfers(char *out, uint32_t out_cap);

/* Messages this device is holding for OTHER people, newest first:
 * [{am,target,sender,ts,size,urg,state,wire}]. state 0 = still to hand on,
 * 1 = delivered and kept for the archive window. `wire` is the frame as text
 * when it is text (XPRS is), else empty. */
__attribute__((import_module("hal"), import_name("mesh_held")))
int32_t hal_mesh_held(char *out, uint32_t out_cap);

/* Set a mesh tunable "key=value" (msgQuotaMb, bulkQuotaMb, scfEnabled). 0 ok.
 * scfEnabled=0 stops carrying other people's mail; 1 (the default) carries. */
__attribute__((import_module("hal"), import_name("mesh_set_pref")))
int32_t hal_mesh_set_pref(const char *kv, uint32_t kv_len);

/* Publish a short status (XPRS section 27) on every bearer this device has
 * active — BLE5 now, a Reticulum broadcast, LoRa the day a radio exists. The
 * wapp supplies the WORDS ONLY: the core builds the packet, splits long text
 * into section 6.6 parts, signs with the profile key, and chooses transports
 * (scope rules applied core-side). [mood] is an optional section 27.1 word and
 * [reply_to] the parent's identifier for a reply (section 27's `r:`); pass
 * NULL/0 for either.
 *
 * The section 5 identifier is written to [id_out] before anything is aired,
 * like hal_xprs_broadcast. Show your own row keyed on it AT ONCE: airing is
 * the core's business and takes as long as it takes, and the copy that comes
 * back — off the air, or out of the spool at the next flush — carries the
 * same identifier and collapses onto the row you already drew.
 *
 * Returns 0 composed (and airing), -1 nothing to publish. */
__attribute__((import_module("hal"), import_name("xprs_status")))
int32_t hal_xprs_status(const char *text, uint32_t text_len,
                        const char *mood, uint32_t mood_len,
                        const char *reply_to, uint32_t reply_to_len,
                        char *id_out, uint32_t id_cap);

/* Correct a status this station posted (XPRS.md 7.8.1). Exactly
 * hal_xprs_status, plus `orig`, the section 5 identifier of the ORIGINAL it
 * corrects (never an earlier edit), and `reply_to`, the parent when the status
 * was a reply (an edit repeats the whole packet, so a reply stays one; NULL/0
 * otherwise): the core builds `edit:<orig>`, splits long text, signs and airs
 * it as a packet of its own. The id written to `id_out` is the EDIT's. 0 composed, -1 nothing to publish. A status is withdrawn by a
 * wire through hal_xprs_send (`r:<orig> remove:status`, section 7.8.2). */
__attribute__((import_module("hal"), import_name("xprs_status_edit")))
int32_t hal_xprs_status_edit(const char *text, uint32_t text_len,
                             const char *orig, uint32_t orig_len,
                             const char *reply_to, uint32_t reply_to_len,
                             char *id_out, uint32_t id_cap);

/* Air one caller-composed XPRS wire. The host validates section 4 syntax,
 * signs it when it speaks as this station and carries no sig:, applies the
 * scope rules (13.11) and spools its own copy. A wire whose m: makes it too
 * long is split by the core into section 6.6 parts (receivers rejoin them
 * before any wapp sees the packet); only an envelope that does not fit
 * without m: is invalid. 0 queued, -1 invalid,
 * -2 refused: a post to a closed group this station is not a member of
 * (26.7) -- the core's decision, the same one its publisher applies to every
 * caller; a wapp only puts it into words. */
__attribute__((import_module("hal"), import_name("xprs_send")))
int32_t hal_xprs_send(const char *wire, uint32_t wire_len);

/* OPEN A REDACTED MESSAGE (9.2.1). A message with ((...)) spans arrives with
 * bars (U+2588) in its text and its hidden pieces in an `xr:` field the wapp
 * never sees. This asks the core to open ONE, by its section 5 identifier.
 *
 * [id] is that identifier, as delivered on the event bus. [pass] is a
 * passphrase the reader typed, or NULL/0 to try the ones the core has
 * remembered plus the default (sixteen '#'). The wapp holds no key, no cipher
 * and no `xr:` blob -- all of it is the core's (9.1/9.2.1).
 *
 * ASYNCHRONOUS: the key derivation is deliberately slow (PBKDF2, 100000
 * iterations) and must not stall the engine, so this returns 0 at once (or -1
 * for an empty id) and the ANSWER arrives on the `xprs.unlock` event:
 *   {"id":..,"ok":true,"text":"<the revealed message>"}   opened, OR
 *   {"id":..,"ok":false}                                  none of the tried
 *                                                         passphrases fit.
 * A passphrase the reader typed that opens the message is remembered by the
 * core, so the next redacted message opens without a prompt -- but the reader
 * still taps every time (persistence removes the prompt, never the tap). */
__attribute__((import_module("hal"), import_name("xprs_unlock")))
int32_t hal_xprs_unlock(const char *id, uint32_t id_len,
                        const char *pass, uint32_t pass_len);

/* AIR A MESSAGE WITH HIDDEN SPANS (9.2.1). The author marked secrets as
 * ((secret)); this hands the marked text and a passphrase to the core, which
 * turns each span into bars, builds the `xr:` blob, signs and airs the packet.
 *
 * [convo] is the conversation id, and it decides how the packet is addressed:
 * a station's callsign or a group's "#X5...." is addressed (`d:`), while
 * "#LOCAL" is the undirected room and goes out scoped instead (13.11.1:
 * `scope:local`, no `d:`). [text] is the marked text; [pass] is the author's
 * passphrase, or NULL/0 for the default. The wapp builds no wire, runs no
 * cipher, and does not decide how the bytes travel.
 *
 * ASYNCHRONOUS (same slow derivation): returns 0 at once, and the author's own
 * barred copy comes back on the `xprs.redacted` event
 *   {"convo":..,"id":..,"m":"<the barred text>","ok":true}
 * to admit as the outgoing bubble -- obfuscated like everyone else sees it, and
 * openable with one tap because the author's passphrase is now remembered.
 * A refusal (nothing marked, no room in a packet, no standing in that group)
 * arrives on the same event as {"convo":..,"ok":false} and carries no id: the
 * message did NOT go out, and the wapp should say so. */
__attribute__((import_module("hal"), import_name("xprs_redact")))
int32_t hal_xprs_redact(const char *convo, uint32_t convo_len,
                        const char *text, uint32_t text_len,
                        const char *pass, uint32_t pass_len);

/* SAY SOMETHING TO SOMEBODY. THE ONLY WAY A WAPP TRANSMITS.
 *
 * The wapp supplies the words and the recipient's callsign. The core composes
 * the packet, seals it (9.2) when [want_private] and it holds the recipient's
 * key, signs it (9.1), splits it (6.6), ranks the bearers on 12.0 evidence,
 * parks a custody copy and remembers the section 5 identifier so a receipt can
 * find it later. Not one of those is a content decision.
 *
 * [want_private] is a set of bits. Bit 0 (1) asks for the sealed form. Bit 1
 * (2) asks the core to KEEP the message while the recipient's key is unknown
 * instead of refusing it: the core holds the words in its encrypted outbox,
 * goes looking for the key (q:identity to the station, `cmd:history
 * kind:identity` to the chosen archivers, XPRS.md 12.12.1), and seals and
 * sends the message the moment the key arrives. The wapp is not told how.
 * Bit 2 (4): [to] is a closed group this station is NOT a member of, and the
 * words are its request to join (10.3): sent in the clear past the membership
 * door, shown only to the group's admin and moderators. A closed group's
 * ordinary post is sealed to its reading key when the group is private and
 * goes in the clear when it is public (10.7.1).
 *
 * Returns  1 sealed, 2 plain,
 *          3 plain, to a node of another network (section 3.2, `MT...`)
 *            through a gateway: the words cross a channel anybody can read,
 *          4 held (bit 1 set, no key yet): [id_out] receives a HELD id of the
 *            same shape as a section 5 identifier. Key the bubble on it. When
 *            the message goes, `xprs.status.tx` arrives with `id` = the held
 *            id, `state` "sent", `newId` = the real identifier and `sealed`
 *            true: move the bubble to newId. `state` "expired" means it was
 *            given up on. hal_xprs_withdraw on a held id takes it back
 *            without anything having been aired (to send it in the open,
 *            withdraw it and send again with bit 0 clear),
 *         -1 privacy asked for and not possible -- the recipient's key has not
 *            been heard; the core has just asked for it (18.1), so try again
 *            shortly,
 *         -3 privacy asked for a node of another network, which can never be
 *            sealed (9.11.5); nothing was sent, and asking again will not
 *            change that,
 *          0 malformed.
 *
 * -1 IS AN ANSWER, NOT AN ERROR, AND NEVER A DOWNGRADE. Section 12.8 makes
 * plaintext a disclosure, so a request to seal that cannot be met is refused
 * out loud rather than quietly sent in the clear. Label the bubble with the
 * RETURN VALUE, never with what was asked for.
 *
 * On success [id_out] receives the section 5 identifier: 6 lowercase hex and a
 * terminator, so pass a buffer of at least 7. That is what to key the bubble
 * on -- the core's outbox uses the same value, and a t:receipt names it in
 * `r:`, so the tick finds its message without any correlation token of your
 * own invention. */
__attribute__((import_module("hal"), import_name("xprs_message")))
int32_t hal_xprs_message(const char *to, uint32_t to_len,
                         const char *text, uint32_t text_len,
                         uint32_t want_private,
                         char *id_out, uint32_t id_cap);

/* SAY SOMETHING TO EVERYBODY IN REACH. The undirected half of xprs_message.
 *
 * You supply the words, how far they may travel, and what they answer. The
 * core composes the t:message (no `d:`, which is what makes it a broadcast),
 * signs it (9.1), splits it (6.6) and applies 13.11's reach rule when it picks
 * the bearers.
 *
 * [scope] is 13.11: "local" for the bearers in range now (13.11.1 -- Bluetooth,
 * the local network, ESP-NOW and LoRa where the operator says their LoRa is
 * local, and NEVER the internet), "global" for everywhere, or ISO 3166-1
 * alpha-2 codes. Pass NULL/0 for "local". It can only narrow where the words
 * go; it never names a lane, and the core still chooses the bearers.
 *
 * [reply_to] is the section 5 identifier this post answers (6.4), NULL/0 for
 * none.
 *
 * THERE IS NO want_private. Section 9.2 seals to ONE public key, and a
 * broadcast has no recipient -- so this door does not offer a promise it could
 * never keep, which is different from xprs_message, where asking is meaningful
 * and the refusal is the answer.
 *
 *   returns  2 plain (the only form a broadcast has),
 *            0 malformed: no profile, empty text, or a scope word that is
 *              neither local, global nor a country code.
 *
 * Never 1 and never -1: both are answers about sealing.
 *
 * On success [id_out] receives the section 5 identifier -- 6 lowercase hex and
 * a terminator, so pass at least 7. NO RECEIPT WILL EVER NAME IT: 13.7.1
 * excludes a broadcast, because nobody was addressed and so nobody owes one.
 * It is what a t:reaction's `r:` names, and what to key your own bubble on. */
__attribute__((import_module("hal"), import_name("xprs_broadcast")))
int32_t hal_xprs_broadcast(const char *text, uint32_t text_len,
                           const char *scope, uint32_t scope_len,
                           const char *reply_to, uint32_t reply_len,
                           char *id_out, uint32_t id_cap);

/* A person opened a message: the one receipt a wapp owns (XPRS.md 13.7).
 *
 * [id] is the message's section 5 identifier, as delivered on the event bus.
 * The core composes and signs the `t:receipt s:read`, applies 13.7.1's
 * exclusions (no group, no broadcast, no stranger) and picks the lane. A wapp
 * does not compose a receipt, invent a correlation id, or choose a transport.
 *
 * 0 = a read receipt went out. -1 = none did, which is ordinary: the message
 * may have aged out of the core's remembered set, or 13.7.1 may refuse one. */
__attribute__((import_module("hal"), import_name("xprs_read")))
int32_t hal_xprs_read(const char *id, uint32_t id_len);

/* The persistent spool of heard XPRS packets (section 24 serve:history) —
 * everything this station archived, past the traffic ring's 200 entries and
 * across restarts. [query] is a JSON filter, "{}" for the latest:
 *   {"since":"YYYY-MM-DD_hh:mm:ss","until":"...","only":"CALL","limit":n,
 *    "to":["","X5A3F2"],"types":["observation"],"from":"CALL",
 *    "kind":"device","scope":"local","id":"a1b2c3"}
 * since/until window on the packet's own ts:, only matches sender OR
 * addressee (or a hears: list). "types" keeps those packet types. "from" is
 * exactly that author, indexed: what one device said. "kind" (user, device)
 * is every author of that kind, indexed: which devices the archive knows;
 * "station" has no single prefix and selects nothing. "to" keeps only the named destinations — "" means undirected —
 * so a room can ask for the rows it renders instead of sieving the newest N:
 * on a station mid store-and-forward the newest N are its own custody
 * re-airs, and a sieving caller's window carries nothing it can use. "scope"
 * (local, regional, global) is one chat room by the scope its author wrote
 * (XPRS.md 9.11.1); ask a room at a time, or a busy room fills the window
 * and a quiet one looks empty. A core older than the field ignores it. "id"
 * is one packet by its section 5 identifier (the primary key, one row), what a
 * message's Info page reads; it never sets off a fetch. Reply, newest first:
 *   [{ts,heardTs,bearer,rssi,from,to,type,id,mine,own,sig,heard,wire}]
 * `sig` is verified|forged|unverified|unsigned; `heard` counts collapsed
 * duplicate sightings. Returns bytes written, negated size if out is small. */
__attribute__((import_module("hal"), import_name("xprs_history")))
int32_t hal_xprs_history(const char *query, uint32_t query_len,
                         char *out, uint32_t out_cap);

/* The closed groups (section 26) this station knows, and what WE are in each.
 * A wapp cannot work this out for itself: the answer is a replay of signed
 * acts against a callsign->key map the host owns. Reply:
 *   [{call,nick,role,admin,members,candidates,verified,parent}]
 * `parent` is the group that lists this one as a subgroup (XPRS.md 10.2), a
 * folder, and is absent for a root; the core applies the five-level and
 * no-cycle rules, so the wapp draws the tree as given.
 * `role` is admin|mod|member|invited|none. Only member, mod and admin may
 * post — 26.3.1 says a grant confers nothing until the person accepts it, so
 * `invited` is somebody who has been ASKED and has not answered. `verified`
 * is false when the group's announcement has not arrived, in which case 26.7
 * says fail open: show the record and say it could not be checked.
 * Returns bytes written, negated size if out is small. */
__attribute__((import_module("hal"), import_name("xprs_groups")))
int32_t hal_xprs_groups(char *out, uint32_t out_cap);

/* One closed group's roster as a flat JSON array [{"call","role","state"}] --
 * the callsigns the member panel shows (hal_xprs_groups only COUNTS them).
 * `state` is "member" (role member/mod/admin) or "invited" (an open offer,
 * 26.3.1: not a member yet). The group's own callsign is never listed. Bytes
 * written, negated size if `out` is small, 0 for an empty/nameless group. */
__attribute__((import_module("hal"), import_name("xprs_group_roster")))
int32_t hal_xprs_group_roster(const char *group, uint32_t group_len,
                              char *out, uint32_t out_cap);

/* Mint a closed group (section 26.1) named `nick` (may be empty) and write its
 * X5 callsign into `out`. The core generates and keeps the group's key, records
 * this station as a member, and announces the group; the wapp never sees the
 * key. The callsign is written before anything is aired, so the caller can
 * open the group's room at once. Bytes written, -1 when no group could be
 * minted (no profile open). */
__attribute__((import_module("hal"), import_name("xprs_group_create")))
int32_t hal_xprs_group_create(const char *nick, uint32_t nick_len,
                              char *out, uint32_t out_cap);

/* Callsigns a new group could have (section 26.1), comma separated, `count`
 * of them (1..64). The callsign derives from the group's key, so the core
 * mints a key for each and holds it in memory until hal_xprs_group_create_as
 * picks one; the wapp never sees the keys. A negative `count` asks for that
 * many MORE, keeping the ones already offered (so a dialog can turn through
 * callsigns without end and still create any shown before); only the new ones
 * are written. Bytes written, negated size if `out` is small, -1 with no
 * profile open. */
__attribute__((import_module("hal"), import_name("xprs_group_candidates")))
int32_t hal_xprs_group_candidates(int32_t count, char *out, uint32_t out_cap);

/* hal_xprs_group_create with the callsign `call` the person picked among
 * hal_xprs_group_candidates. One not offered (or empty) mints a fresh key,
 * so `out` holds the group's callsign either way. Bytes written, -1 when no
 * group could be minted. */
__attribute__((import_module("hal"), import_name("xprs_group_create_as")))
int32_t hal_xprs_group_create_as(const char *nick, uint32_t nick_len,
                                 const char *call, uint32_t call_len,
                                 char *out, uint32_t out_cap);

/* Offer membership of closed group `group` ("X5..." or "#X5...") to station
 * `call` (section 26.3, a grant with role member), or to several stations
 * separated by commas, which the core grants in as few packets as fit. The
 * core signs it with the group's key, which only the admin holds; the station
 * is listed as invited until it accepts (26.3.1). 0 = offered, -1 = refused
 * (not the admin). */
__attribute__((import_module("hal"), import_name("xprs_group_invite")))
int32_t hal_xprs_group_invite(const char *group, uint32_t group_len,
                              const char *call, uint32_t call_len);

/* Take `call`'s place in closed group `group` away (section 26.3, a revoke).
 * Signed with the group's key, so only the admin; it needs no acceptance
 * (26.3.1). 0 = removed, -1 = refused (not the admin). */
__attribute__((import_module("hal"), import_name("xprs_group_remove")))
int32_t hal_xprs_group_remove(const char *group, uint32_t group_len,
                              const char *call, uint32_t call_len);

/* Leave closed group `group` (26.3.1's `leave:group`), signed with this
 * station's own key: the member's decision, on the record. 0 = left,
 * -1 = refused (not a member). */
__attribute__((import_module("hal"), import_name("xprs_group_leave")))
int32_t hal_xprs_group_leave(const char *group, uint32_t group_len);

/* The admin makes member `call` of closed group `group` a moderator (on=1: an
 * offer, `grant role:mod`, which they take up with hal_xprs_group_accept and
 * stay a member meanwhile) or takes the role back (on=0: at once, no consent
 * needed), XPRS.md 10.3. hal_xprs_groups reports `"offer":"mod"` to the one
 * asked, and hal_xprs_group_roster on their row. 0 = done, -1 = refused (not
 * the admin). */
__attribute__((import_module("hal"), import_name("xprs_group_appoint")))
int32_t hal_xprs_group_appoint(const char *group, uint32_t group_len,
                               const char *call, uint32_t call_len, int32_t on);

/* Make closed group `group` private (on=1: sealed with a reading key, only
 * members read) or public (on=0: anyone reads, only members post), XPRS.md
 * 10.7.1. A group is public until its admin says otherwise. 0 = done, -1 =
 * refused (not the admin). */
__attribute__((import_module("hal"), import_name("xprs_group_private")))
int32_t hal_xprs_group_private(const char *group, uint32_t group_len, int32_t on);

/* Correct a message this station sent to `to` (XPRS.md 7.8.1). Exactly
 * hal_xprs_message, plus `orig`, the section 5 identifier of the ORIGINAL it
 * corrects (never an earlier edit): the core builds `edit:<orig>`, seals it as
 * the original was (`want_private`), splits, signs and airs it as a packet of
 * its own. Same return codes as hal_xprs_message; the id written to `id_out`
 * is the EDIT's, the one a receipt names. A group or an open room is corrected
 * by a wire through hal_xprs_send, the way it is posted to. */
__attribute__((import_module("hal"), import_name("xprs_edit")))
int32_t hal_xprs_edit(const char *to, uint32_t to_len,
                      const char *orig, uint32_t orig_len,
                      const char *text, uint32_t text_len,
                      uint32_t want_private, char *id_out, uint32_t id_cap);

/* Withdraw a message this station sent to `to` (XPRS.md 7.8.2): `r:<orig>
 * remove:message`, a packet with no body that travels as the original did. A
 * carrier holding the original discards its copy on hearing it. 0 = aired,
 * -1 = not a valid request. A group or an open room is withdrawn from by a
 * wire through hal_xprs_send. `orig` may also be a HELD id (hal_xprs_message
 * returned 4): the message never left, so it is dropped from the core's
 * outbox, nothing is aired, and the answer is 0. */
__attribute__((import_module("hal"), import_name("xprs_withdraw")))
int32_t hal_xprs_withdraw(const char *to, uint32_t to_len,
                          const char *orig, uint32_t orig_len);

/* The edits and removals of other people's publications that are in force in
 * ONE closed group (XPRS.md 10.4.1), as a JSON array
 * [{"id","kind":"edit"|"remove","target","signer","srole":"mod"|"admin",
 * "ts":<epoch seconds>,"text"}], oldest first. The core has verified each
 * signature, judged the signer's authority at the act's own ts and left out
 * what the admin voided; whether an act binds the publication's author is for
 * the holder of the original, with hal_xprs_group_role_at. Bytes written,
 * negated size if `out` is small. */
__attribute__((import_module("hal"), import_name("xprs_group_moderation")))
int32_t hal_xprs_group_moderation(const char *group, uint32_t group_len,
                                  char *out, uint32_t out_cap);

/* What `call` was in closed group `group` at `ts` (epoch seconds): 0 none,
 * 1 invited, 2 member, 3 moderator, 4 admin (XPRS.md 10.4). */
__attribute__((import_module("hal"), import_name("xprs_group_role_at")))
int32_t hal_xprs_group_role_at(const char *group, uint32_t group_len,
                               const char *call, uint32_t call_len,
                               uint32_t ts);

/* A moderator's or the admin's act on somebody else's publication in closed
 * group `group` (XPRS.md 10.4.1): kind 1 replaces the text of the publication
 * whose section 5 identifier is `target` with `text`, kind 2 removes it (the
 * text is ignored). The core signs as the group when this station is its
 * admin, as itself when it is a moderator. 0 = aired, -1 = not a valid request
 * or it did not fit one packet, -2 = not a moderator or the admin. */
__attribute__((import_module("hal"), import_name("xprs_group_moderate")))
int32_t hal_xprs_group_moderate(const char *group, uint32_t group_len,
                                const char *target, uint32_t target_len,
                                const char *text, uint32_t text_len,
                                uint32_t kind);

/* A folder inside closed group `parent` ("X5..." or "#X5..."), named `nick`
 * (may be empty): what XPRS.md 10.2 calls a subgroup, a closed group of its
 * own with its own key and roster, listed by the parent with role:sub. The
 * core mints and keeps the key and signs the listing with the parent's key,
 * so only the parent's admin can make one. Membership does not travel down:
 * nobody is offered a place until invited with hal_xprs_group_invite. The
 * folder's X5 callsign is written into `out` before anything is aired.
 * Bytes written, -1 when refused (not the admin, five levels deep already,
 * no profile open). hal_xprs_groups names a folder's parent in `parent`. */
__attribute__((import_module("hal"), import_name("xprs_group_folder")))
int32_t hal_xprs_group_folder(const char *parent, uint32_t parent_len,
                              const char *nick, uint32_t nick_len,
                              char *out, uint32_t out_cap);

/* Set closed group `group`'s picture (XPRS.md 6.3.2 on the group's own
 * t:identity, 10.1), signed with the group's key, so only its admin can.
 * `token` is the `file:` reference the host's `ui.pick.picture` answered
 * with (a small square thumbnail); empty takes the picture back. The host
 * draws a group's picture wherever it draws the group. 0 = announced,
 * -1 = refused. */
__attribute__((import_module("hal"), import_name("xprs_group_picture")))
int32_t hal_xprs_group_picture(const char *group, uint32_t group_len,
                               const char *token, uint32_t token_len);

/* Public groups ranked across the groups indexes of this station's
 * archivers (XPRS.md 12.9.7). `by`: "active" (posts this week and the last,
 * posters breaking a tie), "members" or "growing" (joins in the last four
 * weeks); an open group ranks under "active" only. Asking also reads any
 * index an archiver named since; that answer arrives later as core.groups.
 * Writes {"sources":N,"rows":[{"g","name","open","members","posts",
 * "posters","joins"}]}, fifty rows at most. Bytes written; negative: the
 * size needed. */
__attribute__((import_module("hal"), import_name("xprs_group_rank")))
int32_t hal_xprs_group_rank(const char *by, uint32_t by_len, char *out,
                            uint32_t out_cap);

/* Close closed group `group` to new posts (`on` = 1), or open it again (0):
 * `state:closed` / `state:open` under t:moderate (XPRS.md 10.4.2). Its admin
 * and its moderators can, and they still post while it is closed; nobody is
 * removed. hal_xprs_groups reports `"closed":true`. 0 = announced,
 * -1 = refused. */
__attribute__((import_module("hal"), import_name("xprs_group_closed")))
int32_t hal_xprs_group_closed(const char *group, uint32_t group_len, int32_t on);

/* Rename closed group `group` (a folder is one, XPRS.md 10.2): the nick: of
 * its own t:identity (6.3.2, 10.1), signed with the group's key, so only its
 * admin can. hal_xprs_groups reports the new name. 0 = announced,
 * -1 = refused (not the admin, or no name). */
__attribute__((import_module("hal"), import_name("xprs_group_rename")))
int32_t hal_xprs_group_rename(const char *group, uint32_t group_len,
                              const char *nick, uint32_t nick_len);

/* Accept the membership of closed group `group` ("X5..." or "#X5...") that
 * this station was offered (section 26.3.1). The core finds the offer and
 * signs the acceptance with the profile key. 0 = joined, -1 = refused (no
 * offer for this station, or it was withdrawn). */
__attribute__((import_module("hal"), import_name("xprs_group_accept")))
int32_t hal_xprs_group_accept(const char *group, uint32_t group_len);

/* Set a spool tunable "key=value": archive (0/1), archiveMaxMb,
 * archiveMaxDays, serveHistory (0/1 — answer cmd:history and say
 * serve:history in the beacon), archivers (CSV of callsigns), archiverAuto (0/1 — auto-select an
 * archiver when none is listed) — the chosen archiver devices, this station's
 * chosen archiver devices, the one list it pushes copies to (36) AND declares
 * daily as t:mailbox hold: (13.12); empty clears it). 0 ok, -1 unknown key or
 * bad value. */
__attribute__((import_module("hal"), import_name("xprs_set_pref")))
int32_t hal_xprs_set_pref(const char *kv, uint32_t kv_len);

/* Read this station's archiver settings back, as a JSON object:
 *   {"list":["X3RLY7",..],"auto":true}
 * `list` is the chosen archiver devices in preference order (set with
 * `archivers=`); `auto` is the auto-select flag (set with `archiverAuto=`): when
 * true and `list` is empty, the station lets a volunteer node keep its messages.
 * Negated required size when [out_cap] is too small, as with the other reads. */
__attribute__((import_module("hal"), import_name("xprs_archivers")))
int32_t hal_xprs_archivers(char *out, uint32_t out_cap);

/* What this station keeps, and for whom (XPRS.md 12's three tiers) -> JSON.
 *
 *   {"public":bool,          keeps strangers' packets, announces serve:archive
 *    "alwaysOn":bool,        the further promise; false unless public is on
 *    "alwaysOnStored":bool,  the raw switch, so a screen can show it greyed
 *    "keepFollowed":bool, "keepChatter":bool,
 *    "quotaMb":n, "maxDays":n,        the STRANGERS' limits; mine and the
 *                                     people I follow are exempt from both
 *    "records":{"own":n,"followed":n,"stranger":n,"total":n},
 *    "bytes":n, "bytesText":"…", "quotaText":"…", "fullFrac":0..1,
 *    "followedCallsigns":n,
 *    "asksLastHour":n, "answered":n, "refused":n,
 *    "announced":"archive,files"|"",   what the beacon actually claims
 *    "named":["X3ARC1",…]}             archivers the operator wrote down
 *
 * There is no "super": section 13's serve: vocabulary has `archive` and
 * nothing above it, and 12.9.4 describes an always-on archiver by its
 * qualities rather than by a rank. Read it when `core.archive` fires. */
__attribute__((import_module("hal"), import_name("xprs_archive")))
int32_t hal_xprs_archive(char *out, uint32_t out_cap);

/* Browse a nearby station's custody store and take chosen messages with you.
 * Kick-off-and-poll (a dial takes seconds; a HAL call may not stall the
 * engine): cmd is JSON —
 *   {"op":"browse","station":"X3JS7Y"}            start the dial
 *   {"op":"status"}                               poll (cheap, idempotent)
 *   {"op":"pull","station":"X3JS7Y","ids":[...]}  take custody of these
 *   {"op":"reset"}                                leave the listing
 * Reply: {"state":"idle|busy|done|fail|pulling|pulled","station","pulled",
 * "entries":[{"id","target","len","age","urg"}]} — envelopes only, never
 * content. Pulled messages land in THIS device's store (hal_mesh_held).
 * Returns bytes written, negated required size when out_cap is too small. */
__attribute__((import_module("hal"), import_name("mesh_carry")))
int32_t hal_mesh_carry(const char *cmd, uint32_t cmd_len,
                       char *out, uint32_t out_cap);

/* ── Contacts (people this device already knows) ─────────────────────── *
 *
 * A reusable picker source: the people the user can address — those seen on
 * APRS (where a callsign is bound to a public key) and those they follow —
 * so a wapp can offer "add from contacts" instead of pasting a raw key. The
 * result is a JSON array of objects {"npub":..,"callsign":..,"nick":..}.
 * [query] filters case-insensitively across npub, callsign and nickname (an
 * empty query returns everyone). A callsign is only present when its npub is
 * known, so a contact returned here can always be added by any of the three.
 * Returns bytes written, -1 on error, or -2 if the buffer was too small. */
__attribute__((import_module("hal"), import_name("contacts_query")))
int32_t hal_contacts_query(const char *query, uint32_t query_len,
                           char *out, uint32_t out_cap);

/* People search across contacts AND the live announce registry, aggregated by
 * callsign — the host's "find a user" search. Result: JSON array of
 * {"npub","callsign","nick","online":bool,"devices":n}. Empty query → [].
 * Returns bytes written, -1 on error, -2 if the buffer was too small. */
__attribute__((import_module("hal"), import_name("people_search")))
int32_t hal_people_search(const char *query, uint32_t query_len,
                          char *out, uint32_t out_cap);

/* Everyone this device could start a conversation with, in ONE list — LXMF
 * peers heard on the Reticulum mesh (NomadNet, Sideband, other xprs
 * devices) and xprs people (callsign / npub). JSON array of
 *   {"kind":"lxmf","dest","name","callsign","identity","xprs":bool,
 *    "hops","via","lastSeen","live":bool}
 *   {"kind":"xprs","callsign","npub","nick","devices","live":bool}
 * sorted live-first then newest-heard. An empty query returns everyone.
 *
 * NOT liveness-gated: LXMF stores and forwards, so a peer heard once is still
 * messageable, and a hub's replayed announce table is exactly the population a
 * NomadNet client lists. `live` reports the strict "online now" answer instead
 * of hiding people. Returns bytes written, -1 error, -2 buffer too small. */
__attribute__((import_module("hal"), import_name("people_directory")))
int32_t hal_people_directory(const char *query, uint32_t query_len,
                             char *out, uint32_t out_cap);

#ifdef __cplusplus
}
#endif

#endif /* XPRS_WASM_HAL_H */
